import subfolder.main as m

m.display_on_main()