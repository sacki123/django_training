import module
import sys

print(sys.path)

def display_on_main():
    print("display on main")

module.display_on_module()