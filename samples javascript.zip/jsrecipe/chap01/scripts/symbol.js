let s = Symbol('hoge');
let s2 = Symbol('hoge');

console.log(typeof s);
console.log(s.toString());
console.log(s === s2);
// console.log(s + 'a');
// console.log(s - 1);
console.log(typeof !!s);
