function square(height, width) {
  return
  height * width;
}

console.log(square(2, 3));
