console.log(typeof String(123));
console.log(typeof new String(123));
