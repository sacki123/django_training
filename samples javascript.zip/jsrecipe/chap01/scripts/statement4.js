console.log('hoge'); console.log('foo');
