console.log('JavaScriptの文は、');
console.log('「;」で終えるべきです');

// let myFnc = function () { /* 任意のコード */ }	
// (function () { /* 任意のコード */ })();
