console.log(typeof String(123));
console.log(typeof Boolean(-1));

