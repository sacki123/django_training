let data;
console.log(data);
let obj = { hoge: 123, piyo: 456 };
console.log(obj.data);
let fn = function () { };
console.log(fn());

