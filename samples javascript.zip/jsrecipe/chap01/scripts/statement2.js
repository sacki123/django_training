console
.
log
(
'こんにちは、世界！'
);