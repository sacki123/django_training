console.log('こんにちは\nJavaScript！');
