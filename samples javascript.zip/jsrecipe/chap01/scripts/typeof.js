let num = 100;
console.log(typeof num);
let str = 'はじめまして';
console.log(typeof str);
let flag = false;
console.log(typeof flag);
let flag2 = new Boolean(false);
console.log(typeof flag2);
let ary = ['Vue.js', 'TypeScript', 'ECMAScript']
console.log(typeof ary);
let obj = { a: 100, b: 200 };
console.log(typeof obj);
let ex = /^[A-Za-z]{1,}/;
console.log(typeof ex);
