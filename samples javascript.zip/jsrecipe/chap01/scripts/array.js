let data1 = new Array('JavaScript', 'CoffeeScript', 'TypeScript');
let data2 = ['JavaScript', 'CoffeeScript', 'TypeScript'];

console.log(data1);
console.log(data2);

