// let flag = false;
let flag = new Boolean(false);

if (flag) {
  console.log('表示されない…はず');
}
