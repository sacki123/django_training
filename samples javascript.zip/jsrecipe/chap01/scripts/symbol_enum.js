const SPRING = Symbol();
const SUMMER = Symbol();
const AUTUMN = Symbol();
const WINTER = Symbol();

// const SPRING = 0;
// const SUMMER = 1;
// const AUTUMN = 2;
// const WINTER = 3;

const MONDAY = 0;

let season = SPRING;

if (season === SPRING) {
  console.log('seasonとSPRINGは同じ');
}

if (season === 0) {
  console.log('seasonと0は同じ');
}

if (season === MONDAY) {
  console.log('seasonとMONDAYは同じ');
}
