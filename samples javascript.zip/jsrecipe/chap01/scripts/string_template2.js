let name = '山田太郎';
console.log(`こんにちは、${name}さん!`);
console.log(`逆引きレシピ\${hoge}JavaScript`);
