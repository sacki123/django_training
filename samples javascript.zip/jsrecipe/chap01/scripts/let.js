let msg = 'こんにちは、世界！';
let j;
i = 3;
let name1 = 'Rio', name2 = 'Nami';

console.log(msg);
console.log(j);
console.log(i);
console.log(name1);
console.log(name2);
