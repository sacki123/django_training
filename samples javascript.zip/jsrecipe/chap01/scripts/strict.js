// 'use strict';

console.log('JavaScriptです。');

function sample() {
  'use strict';
  // 関数の実体
}
