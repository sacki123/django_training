let num = 1.2345;
console.log(num);
let num2 = 0.12345e-10;
console.log(num2);
