let message = `こんにちは
JavaScript！`;
console.log(message);
