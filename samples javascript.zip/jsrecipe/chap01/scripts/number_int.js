let num = -10;
console.log(num);
let num2 = 0xFF;
console.log(num2);
let num3 = 0o500;
console.log(num3);
let num4 = 0b111;
console.log(num4);
