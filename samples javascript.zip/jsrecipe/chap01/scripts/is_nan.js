console.log(Number.isNaN('xyz'));
console.log(isNaN('xyz'));
