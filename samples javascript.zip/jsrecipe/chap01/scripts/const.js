const tax = 1.08;
let price = 500;
console.log(price * tax);
