let data = [
  'C#',
  'Java',
  ['MySQL', 'PostgreSQL', 'SQLite'],
];

console.log(data[1]);
console.log(data[2][2]);
