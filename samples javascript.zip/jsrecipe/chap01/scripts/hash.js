let obj1 = { a: 100, b: 500, c: 800 };
let obj2 = new Object();
obj2.a = 100;
obj2.b = 500;
obj2.c = 800;

console.log(obj1.b);
console.log(obj1['b']);
