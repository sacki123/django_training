let str1 = 'こんにちは、文字列！';
let str2 = "こんにちは、文字列！";

window.alert(str1);

console.log(str2);

document.getElementById('result').textContent = str2;

document.write(str1);
