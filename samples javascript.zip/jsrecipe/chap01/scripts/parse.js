let data1 = '888abc';
console.log(Number.parseInt(data1));
console.log(Number.parseFloat(data1));
console.log(Number(data1));

let data2 = '0x10';
console.log(Number.parseInt(data2));
console.log(Number.parseFloat(data2));
console.log(Number(data2));

let data3 = '1.414E3';
console.log(Number.parseInt(data3));
console.log(Number.parseFloat(data3));
console.log(Number(data3));

let data4 = '0b100';
console.log(Number.parseInt(data4));
console.log(Number.parseFloat(data4));
console.log(Number(data4));

let data5 = new Date();
console.log(Number.parseInt(data5));
console.log(Number.parseFloat(data5));
console.log(Number(data5));
