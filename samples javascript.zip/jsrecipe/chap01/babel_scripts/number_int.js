"use strict";

var num = -10;
console.log(num);
var num2 = 0xFF;
console.log(num2);
var num3 = 320;
console.log(num3);
var num4 = 7;
console.log(num4);