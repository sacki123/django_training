"use strict";

var message = "\u3053\u3093\u306B\u3061\u306F\nJavaScript\uFF01";
console.log(message);