'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var s = Symbol('symbol');
var s2 = Symbol('symbol');

console.log(typeof s === 'undefined' ? 'undefined' : _typeof(s));
console.log(s.toString());
console.log(s === s2);
// console.log(s + 'a');
// console.log(s - 1);
console.log(_typeof(!!s));