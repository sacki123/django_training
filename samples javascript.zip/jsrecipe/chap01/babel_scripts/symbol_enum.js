'use strict';

var SPRING = Symbol();
var SUMMER = Symbol();
var AUTUMN = Symbol();
var WINTER = Symbol();

// let SPRING = 0;
// let SUMMER = 1;
// let AUTUMN = 2;
// let WINTER = 3;

var MONDAY = 0;

var season = SPRING;

if (season === SPRING) {
  console.log('同じ');
}

if (season === 0) {
  console.log('同じ');
}

if (season === MONDAY) {
  console.log('同じ');
}