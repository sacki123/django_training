'use strict';

var name = '山田太郎';
console.log('\u3053\u3093\u306B\u3061\u306F\u3001' + name + '\u3055\u3093!');
console.log('\u9006\u5F15\u304D\u30EC\u30B7\u30D4${hoge}JavaScript');