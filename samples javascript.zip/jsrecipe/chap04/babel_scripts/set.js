'use strict';

var s = new Set(['ド', 'ミ', 'ソ', 'ド']);
console.log(s);

var s2 = new Set([NaN, NaN]);
var s3 = new Set([{}, {}]);
console.log(s2.size);
console.log(s3.size);