'use strict';

var data1 = ['a', 'b', 'c'];
var data2 = [{ x: 1, y: 2 }, { x: 3, y: 4 }, { x: 5, y: 6 }];

var copy1 = Array.from(data1);
var copy2 = Array.from(data2);

data1[0] = 'zzz';
data2[0].x = 999;

console.log(data1);
console.log(copy1);
console.log(data2);
console.log(copy2);