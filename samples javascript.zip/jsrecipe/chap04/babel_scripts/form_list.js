'use strict';

document.addEventListener('DOMContentLoaded', function () {
  var getListbox = function getListbox(name) {
    var result = [];
    Array.from(document.getElementById(name).options).forEach(function (elem) {
      // Array.prototype.forEach.call(document.getElementById(name).options, function (elem) {
      if (elem.selected) {
        result.push(elem.value);
      }
    });
    return result;
  };
  document.getElementById('os').addEventListener('change', function () {
    console.log(getListbox('os'));
  }, false);
}, false);