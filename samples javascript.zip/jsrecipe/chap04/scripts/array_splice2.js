let data = ['ぱんだ', 'うさぎ', 'こあら', 'たぬき', 'きつね'];
console.log(data.splice(2, 0, 'さる'));
console.log(data);
console.log(data.splice(4, 2));
console.log(data);
