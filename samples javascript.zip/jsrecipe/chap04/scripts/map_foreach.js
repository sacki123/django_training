let m = new Map();
m.set('Fl', 'フルート');
m.set('Tp', 'トランペット');
m.set('Vn', 'ヴァイオリン');

m.forEach(function (value, key) {
  console.log(key + '：' + value);
});
