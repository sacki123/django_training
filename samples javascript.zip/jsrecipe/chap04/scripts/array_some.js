let animals = [
  'フレンチブルドッグ',
  'ヨークシャーテリア',
  'ダックスフント',
  'ポメラニアン',
  'コーギー',
];
console.log(animals.some(function (value) {
  return (value.length < 8);
}));
