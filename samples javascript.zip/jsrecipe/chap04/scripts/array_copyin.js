let data = ['ド', 'レ', 'ミ', 'ファ', 'ソ'];
let data2 = ['ド', 'レ', 'ミ', 'ファ', 'ソ'];
let data3 = ['ド', 'レ', 'ミ', 'ファ', 'ソ'];
console.log(data.copyWithin(2, 1, 3));
console.log(data2.copyWithin(1, 2));
console.log(data3.copyWithin(2));
