let m = new Map();
m.set({}, 'WINGS');
console.log(m.get({}));
