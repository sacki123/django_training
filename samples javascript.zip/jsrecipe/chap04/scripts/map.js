let m = new Map([
  ['Fl', 'フルート'],
  ['Tp', 'トランペット'],
  ['Vn', 'ヴァイオリン'],
]);
console.log(m);
console.log(m.size);
