let m = new Map();
m.set('Fl', 'フルート');
m.set('Tp', 'トランペット');
console.log(m.delete('Fl'));
console.log(m.delete('Cl'));
m.clear();
console.log(m);
