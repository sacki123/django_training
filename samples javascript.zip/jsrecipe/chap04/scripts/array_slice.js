let data = ['ぱんだ', 'うさぎ', 'こあら', 'たぬき', 'きつね'];
console.log(data.slice(1));
console.log(data.slice(1, 3));
console.log(data.slice(1, -1));
