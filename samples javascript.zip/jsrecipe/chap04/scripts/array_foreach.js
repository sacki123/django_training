let animals = [
  { name: 'フレンチブルドッグ', type: 'いぬ' },
  { name: 'ヨークシャーテリア', type: 'いぬ' },
  { name: 'ダックスフント', type: 'いぬ' },
  { name: 'スコティッシュ フォールド', type: 'ねこ' },
  { name: 'ポメラニアン', type: 'いぬ' },
];
animals.forEach(function (value) {
  console.log(value.name + '：' + value.type);
});
