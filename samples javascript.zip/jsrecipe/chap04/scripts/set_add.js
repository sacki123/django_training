let s = new Set();
s.add('ド');
s.add('ミ');
s.add('ソ');
s.add('ド');
console.log(s);

// s.add('ド').add('ミ').add('ソ').add('ド');
// console.log(s);
