let data = ['ぱんだ', 'うさぎ', 'こあら', 'うし'];
console.log(data.includes('うさぎ'));
console.log(data.includes('うさぎ', 2));
console.log(data.includes('うさぎ', -3));
console.log(data.includes('うさぎ', -2));
