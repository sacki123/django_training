let data = [7, 38, 21];
console.log(data.sort());
console.log(data.sort(function (m, n) { return m - n; }));

