let s = new Set();
s.add('ド');
s.add('ミ');
s.add('ソ');
s.forEach(function (value) {
  console.log(value);
});
