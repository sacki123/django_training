let data1 = {
  id: 10,
  name: 'Yamada',
  description: {
    birth: '1978-02-25'
  },
};
let data2 = {
  age: 40,
  married: true,
  description: {
    job: '塾講師'
  },
};
let data3 = {
  blood: 'A',
  name: 'Taro Yamada',
};

Object.assign(data1, data2, data3);
// let merged = Object.assign({}, data1, data2, data3);
console.log(data1);
