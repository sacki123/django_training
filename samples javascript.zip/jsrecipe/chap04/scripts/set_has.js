let s = new Set();
s.add('ド');
s.add('ミ');
s.add('ソ');
console.log(s.has('ド'));
console.log(s.has('レ'));
