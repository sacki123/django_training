function indexOfAll(array, search) {
  let result = [];
  let index = -1;
  do {
    index = array.indexOf(search, index + 1);
    result.push(index);
  } while (index !== -1);
  return result.slice(0, result.length - 1);
}

let data = ['赤', '白', '青', '赤', '赤'];
console.log(indexOfAll(data, '赤'));
