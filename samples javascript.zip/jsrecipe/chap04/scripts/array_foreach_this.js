let animals = [
  { name: 'フレンチブルドッグ', type: 'いぬ' },
  { name: 'ヨークシャーテリア', type: 'いぬ' },
  { name: 'ダックスフンド', type: 'いぬ' },
  { name: 'スコティッシュ フォールド', type: 'ねこ' },
  { name: 'ポメラニアン', type: 'いぬ' },
];
let result = [];
animals.forEach(function (value) {
  this.push(value.name + ':' + value.type);
}, result);
console.log(result);
