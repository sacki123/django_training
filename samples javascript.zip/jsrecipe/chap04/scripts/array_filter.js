let animals = [
  'フレンチブルドッグ',
  'ヨークシャーテリア',
  'ダックスフント',
  'ポメラニアン',
  'コーギー',
];
let short = animals.filter(function (value) {
  return (value.length < 8);
});
console.log(short);
