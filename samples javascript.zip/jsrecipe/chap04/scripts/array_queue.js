let data = [1, 2, 3];
console.log(data);
console.log(data.push(4));
console.log(data);
console.log(data.shift());
console.log(data);
