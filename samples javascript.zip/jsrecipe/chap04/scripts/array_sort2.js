let key = ['部長', '課長', '係長', '主任'];
let data = [
  { name: '山田リオ', position: '主任' },
  { name: '鈴木奈美', position: '部長' },
  { name: '田中博', position: '課長' },
  { name: '佐藤平八', position: '課長' },
];
console.log(data.sort(function (m, n) {
  return key.indexOf(m.position) - key.indexOf(n.position);
}));
