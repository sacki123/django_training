let data = [
  ['ぱんだ', 2], ['うさぎ', 5], ['こあら', 1]
];
console.log(data.reduce(function (result, value) {
  return result.concat(value);
}));
console.log(data.reduceRight(function (result, value) {
  return result.concat(value);
}));
