let data1 = ['ぱんだ', 'うさぎ', 'こあら'];
let data2 = ['たぬき', 'きつね', 'さる'];
let data3 = ['うし', 'うま', 'とり'];
console.log(data1.concat(data2));
console.log(data1.concat(data2, data3));
data1.push(data2);
console.log(data1);
