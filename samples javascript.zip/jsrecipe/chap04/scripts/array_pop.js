let data = ['ぱんだ', 'うさぎ', 'こあら'];
data.push('はむすたぁ');
data.unshift('ねこ');
console.log(data);
console.log(data.pop());
console.log(data.shift());
console.log(data);
