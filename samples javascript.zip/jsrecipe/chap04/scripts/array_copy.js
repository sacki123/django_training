let data = ['ぱんだ', 'うさぎ', 'こあら'];
let copy = Array.from(data);
console.log(data);
console.log(copy);
console.log(data === copy);

// let copy = data;
// console.log(data === copy);