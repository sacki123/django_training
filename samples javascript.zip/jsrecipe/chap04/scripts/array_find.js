let books = [
  {
    title: '独習C# 新版',
    price: 3600,
  },
  {
    title: '速習 webpack ',
    price: 454,
  },
  {
    title: 'Angularアプリプログラミング',
    price: 3700,
  },
];
console.log(books.find(function (value) {
  return (value.price < 2000);
}));
