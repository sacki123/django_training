let data = ['ぱんだ', 'うさぎ', 'こあら', 'たぬき', 'きつね'];
console.log(data.splice(2, 2, 'さる', 'きじ', 'いぬ'));
console.log(data);
console.log(data.splice(0, 1, 'ねこ', 'ぶた'));
console.log(data);
console.log(data.splice(-2, 2, 'ねずみ'));
console.log(data);
