let s = new Set();
s.add('ド');
s.add('ミ');
s.add('ソ');
console.log(s.delete('ド'));
console.log(s.delete('レ'));
s.clear();
console.log(s);
