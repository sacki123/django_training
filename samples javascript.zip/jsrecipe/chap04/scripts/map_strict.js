let m = new Map();
m.set('10', 'zehn');
console.log(m.get(10));
// console.log(m.get('10'));
