let m = new Map();
m.set(NaN, 'WINGS');
console.log(m.get(NaN));
