let data = [1, 2, 3];
let data2 = data.map(function (value) {
  return value * value;
});
console.log(data2);
