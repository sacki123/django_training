let m = new Map();
m.set('Fl', 'フルート');
m.set('Tp', 'トランペット');
m.set('Vn', 'ヴァイオリン');

for (let key of m.keys()) {
  console.log(key);
}

for (let value of m.values()) {
  console.log(value);
}

for (let [key, value] of m.entries()) {
  console.log(key + '：' + value);
}

// for (let [key, value] of m) {
//   console.log(key + '：' + value);
// }
