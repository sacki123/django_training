let data = ['ぱんだ', 'うさぎ', 'こあら'];
console.log(data.join(' '));
console.log(data.join());
// window.alert(data.toString());
// window.alert(data);
