let m = new Map();
m.set('Fl', 'フルート');
console.log(m.get('Fl'));
