let data = [2, 4, 6, 8];
console.log(data.reduce(function (result, value) {
  return result * value;
}));
