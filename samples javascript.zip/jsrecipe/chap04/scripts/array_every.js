let animals = [
  'フレンチブルドッグ',
  'ヨークシャーテリア',
  'ダックスフント',
  'ポメラニアン',
  'コーギー',
];
console.log(animals.every(function (value) {
  return (value.length < 8);
}));
