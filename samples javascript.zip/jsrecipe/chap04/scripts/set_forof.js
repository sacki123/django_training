let s = new Set();
s.add('ド');
s.add('ミ');
s.add('ソ');
for (let value of s) {
  console.log(value);
}

// for (let value of s.values()) {
//   console.log(value);
// }
