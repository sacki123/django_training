let m = new Map();
m.set('Fl', 'フルート');
console.log(m.has('Fl'));
console.log(m.has('Cl'));
