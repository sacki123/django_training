let data = [ 'あ', 'え', 'い', 'い', 'あ', 'う' ];
let unique = [...(new Set(data))];
console.log(unique);