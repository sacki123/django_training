let data = ['ぱんだ', 'うさぎ', 'こあら'];
for (let i = 0; i < data.length; i++) {
// for (let i = 0, len = data.length; i < len; i++) {
  console.log(data[i]);
}
