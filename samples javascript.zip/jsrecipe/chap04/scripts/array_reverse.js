let data = ['ぱんだ', 'うさぎ', 'こあら'];
console.log(data.reverse());
