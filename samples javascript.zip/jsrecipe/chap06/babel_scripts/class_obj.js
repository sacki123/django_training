"use strict";

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Person = function Person() {
  _classCallCheck(this, Person);
};

var BusinessPerson = function (_Person) {
  _inherits(BusinessPerson, _Person);

  function BusinessPerson() {
    _classCallCheck(this, BusinessPerson);

    return _possibleConstructorReturn(this, (BusinessPerson.__proto__ || Object.getPrototypeOf(BusinessPerson)).apply(this, arguments));
  }

  return BusinessPerson;
}(Person);

var p = new Person();
var bp = new BusinessPerson();
console.log(p.constructor === Person);
console.log(bp.constructor === Person);
console.log(bp.constructor === BusinessPerson);