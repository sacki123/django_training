'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Article = function Article(title, url, intro) {
  _classCallCheck(this, Article);

  this.title = title;
  this.url = url;
  this.intro = intro;
};

var a = new Article('Angular連載', 'https://codezine.jp/article/corner/653', 'JavaScriptフレームワーク「Angular」の活用方法をサンプルを交えて紹介します。');
console.log(a.title);