'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Article = function () {
  function Article(title, url, intro) {
    _classCallCheck(this, Article);

    this.title = title;
    this.url = url;
    this.intro = intro;
  }

  _createClass(Article, [{
    key: 'toString',
    value: function toString() {
      return this.title + '\uFF08' + this.url + '\uFF09\uFF1A\n    ' + this.intro;
    }
  }]);

  return Article;
}();

var a = new Article('Angular連載', 'https://codezine.jp/article/corner/653', 'JavaScriptフレームワーク「Angular」の活用方法をサンプルを交えて紹介します。');
console.log(a.toString());