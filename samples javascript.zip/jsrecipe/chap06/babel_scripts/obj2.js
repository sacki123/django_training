'use strict';

var animal = {
  name: 'さくら',
  birth: new Date(2017, 1, 14),
  toString: function toString() {
    return this.name + ' （' + this.birth.toLocaleDateString() + ' 生まれ）';
  }
};

console.log(animal.toString());