'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Article = function Article(title, url, intro) {
  _classCallCheck(this, Article);

  this.title = title;
  this.url = url;
  this.intro = intro;
};

var a = new Article('Angular連載', 'https://codezine.jp/article/corner/653', 'JavaScriptフレームワーク「Angular」の活用方法をサンプルを交えて紹介します。');
a.getSummary = function () {
  return this.intro.substring(0, 10);
};
console.log(a.getSummary());

var a2 = new Article('PHP連載', 'http://www.atmarkit.co.jp/ait/series/1432/', 'Web開発向けスクリプト言語「PHP」の文法を一から学ぶための入門連載記事です。');
console.log(a2.getSummary());