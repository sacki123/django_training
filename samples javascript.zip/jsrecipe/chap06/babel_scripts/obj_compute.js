'use strict';

var _animal;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var num = 0;
var animal = (_animal = {
  name: 'さくら',
  birth: new Date(2017, 1, 14)
}, _defineProperty(_animal, 'feature' + ++num, 'ハムスター'), _defineProperty(_animal, 'feature' + ++num, 'パールホワイト'), _defineProperty(_animal, 'feature' + ++num, '人懐っこい'), _animal);

console.log(animal);