'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Person = function () {
  function Person(name) {
    _classCallCheck(this, Person);

    this.name = name;
  }

  _createClass(Person, [{
    key: 'show',
    value: function show() {
      return this.name + '\u3067\u3059\u3002';
    }
  }]);

  return Person;
}();

var BusinessPerson = function (_Person) {
  _inherits(BusinessPerson, _Person);

  function BusinessPerson() {
    _classCallCheck(this, BusinessPerson);

    return _possibleConstructorReturn(this, (BusinessPerson.__proto__ || Object.getPrototypeOf(BusinessPerson)).apply(this, arguments));
  }

  _createClass(BusinessPerson, [{
    key: 'work',
    value: function work() {
      return this.name + '\u306F\u30BB\u30C3\u30BB\u3068\u50CD\u304D\u307E\u3059\u3002';
    }
  }]);

  return BusinessPerson;
}(Person);

var bp = new BusinessPerson('山田太郎');
console.log(bp.show());
console.log(bp.work());