'use strict';

function print(_ref) {
  var title = _ref.title;

  console.log(title);
}

var book = {
  title: '独習C# 新版',
  price: 3600,
  publsher: '翔泳社'
};

print(book);