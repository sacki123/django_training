'use strict';

function sprintf(format) {
  for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }

  for (var i = 0; i < args.length; i++) {
    var pattern = new RegExp('\\{' + i + '\\}', 'g');
    format = format.replace(pattern, args[i]);
  }
  return format;
}

console.log(sprintf('{0}を飼っています。名前は{1}です。', 'ハムスター', 'ウタ'));