"use strict";

// let getSquareArea = (width, height) => {
//   return width * height;
// };

var getSquareArea = function getSquareArea(width, height) {
  return width * height;
};

console.log(getSquareArea(2, 3));