"use strict";

function getSquareArea() {
  var width = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  var height = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

  return width * height;
}

console.log(getSquareArea(2));
// console.log(getSquareArea(10, null));
// console.log(getSquareArea(10, undefined));

// 既定値に他の引数を渡した場合
// function getSquareArea(width, height = width) {
//   return width * height;
// }
// console.log(getSquareArea(2, 3));
// console.log(getSquareArea(2));

// 自分より後に定義されたものを参照した場合
// function getSquareArea(width = height, height = 1) {
//   return width * height;
// }
// console.log(getSquareArea());

// 既定値のない引数を、既定値のある引数の後に置いた場合
// function getSquareArea(width = 1, height) {
//   return width * height;
// }
// console.log(getSquareArea(10));