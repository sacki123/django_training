'use strict';

var _templateObject = _taggedTemplateLiteral(['\u306F\u3058\u3081\u307E\u3057\u3066\u3001', '\uFF01'], ['\u306F\u3058\u3081\u307E\u3057\u3066\u3001', '\uFF01']);

function _taggedTemplateLiteral(strings, raw) { return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }

function htmlEscape(str) {
  if (!str) {
    return '';
  }
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/'/g, '&#39;').replace(/"/g, '&quot;');
}

function e(strs) {
  var result = '';

  for (var _len = arguments.length, vars = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    vars[_key - 1] = arguments[_key];
  }

  for (var i = 0; i < strs.length; i++) {
    result += strs[i] + htmlEscape(vars[i]);
  }
  return result;
}

var name = '<"Pochi" & \'Tama\'>';
console.log(e(_templateObject, name));