'use strict';

var _marked = /*#__PURE__*/regeneratorRuntime.mark(mygen);

function mygen() {
  return regeneratorRuntime.wrap(function mygen$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return 'おはよう';

        case 2:
          _context.next = 4;
          return 'こんにちは';

        case 4:
          _context.next = 6;
          return 'おやすみ';

        case 6:
        case 'end':
          return _context.stop();
      }
    }
  }, _marked, this);
}

var itr = mygen();
console.log(itr.next());
console.log(itr.next());
console.log(itr.next());
console.log(itr.next());