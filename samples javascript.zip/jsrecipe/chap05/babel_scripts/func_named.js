'use strict';

function showPanel(_ref) {
  var _ref$path = _ref.path,
      path = _ref$path === undefined ? 'content.html' : _ref$path,
      _ref$height = _ref.height,
      height = _ref$height === undefined ? 200 : _ref$height,
      _ref$width = _ref.width,
      width = _ref$width === undefined ? 300 : _ref$width,
      _ref$resizable = _ref.resizable,
      resizable = _ref$resizable === undefined ? true : _ref$resizable,
      _ref$draggable = _ref.draggable,
      draggable = _ref$draggable === undefined ? true : _ref$draggable,
      _ref$modeless = _ref.modeless,
      modeless = _ref$modeless === undefined ? false : _ref$modeless;

  console.log('path：' + path);
  console.log('height：' + height);
  console.log('width：' + width);
  console.log('resizable：' + resizable);
  console.log('draggable：' + draggable);
  console.log('modeless：' + modeless);
};

showPanel({
  height: 250,
  width: 150,
  path: 'panel.html',
  resizable: false,
  draggable: false,
  modeless: true
});