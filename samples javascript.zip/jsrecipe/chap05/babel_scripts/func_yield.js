'use strict';

var _marked = /*#__PURE__*/regeneratorRuntime.mark(mygen),
    _marked2 = /*#__PURE__*/regeneratorRuntime.mark(subgen);

function mygen() {
  return regeneratorRuntime.wrap(function mygen$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return '春が来た';

        case 2:
          return _context.delegateYield(subgen(), 't0', 3);

        case 3:
          _context.next = 5;
          return '花がさく';

        case 5:
        case 'end':
          return _context.stop();
      }
    }
  }, _marked, this);
}

function subgen() {
  return regeneratorRuntime.wrap(function subgen$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return '山に来た';

        case 2:
          _context2.next = 4;
          return '里に来た';

        case 4:
          _context2.next = 6;
          return '野にも来た';

        case 6:
        case 'end':
          return _context2.stop();
      }
    }
  }, _marked2, this);
}

var _iteratorNormalCompletion = true;
var _didIteratorError = false;
var _iteratorError = undefined;

try {
  for (var _iterator = mygen()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
    var str = _step.value;

    console.log(str);
  }
} catch (err) {
  _didIteratorError = true;
  _iteratorError = err;
} finally {
  try {
    if (!_iteratorNormalCompletion && _iterator.return) {
      _iterator.return();
    }
  } finally {
    if (_didIteratorError) {
      throw _iteratorError;
    }
  }
}