'use strict';

function required(msg) {
  throw new Error(msg);
}

function getSquareArea() {
  var width = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : required('幅が指定されていません。');
  var height = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : required('高さが指定されていません。');

  return width * height;
}

console.log(getSquareArea(2));