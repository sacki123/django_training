function showArgs() {
  var args = Array.prototype.slice.call(arguments);
  return args.join('・');
}
console.log(showArgs('松', '竹', '梅'));
