let scope = 'Global';

function show() {
  let scope = 'Local';
  return scope;
}

console.log(show());
console.log(scope);
