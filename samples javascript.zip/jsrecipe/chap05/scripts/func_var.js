function product(...nums) {
  let result = 1;
  for (let num of nums) {
    result *= num;
  }
  return result;
}

console.log(product(3, 4, 5));
