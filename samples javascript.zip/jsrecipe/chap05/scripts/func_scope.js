let scope = 'Global';

function hoge() {
  let scope = 'Local';

  let literalFnc = function () { return scope; };
  console.log(literalFnc());

  let conFnc = new Function('return scope;');
  console.log(conFnc());
}

hoge();
