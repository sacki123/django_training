(function() {
  var data = 108;
  console.log(data);
}).call(this);

console.log(data);
