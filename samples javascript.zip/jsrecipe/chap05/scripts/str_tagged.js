function htmlEscape(str) {
  if (!str) { return ''; }
  return str.replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/'/g, '&#39;')
    .replace(/"/g, '&quot;');
}

function e(strs, ...vars) {
  let result = '';
  for (let i = 0; i < strs.length; i++) {
    result += strs[i] + htmlEscape(vars[i]);
  }
  return result;
}

let name = '<"Pochi" & \'Tama\'>';
console.log(e`はじめまして、${name}！`);
