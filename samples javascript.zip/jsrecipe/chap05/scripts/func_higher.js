function benchmark(proc) {
  let start = new Date();
  proc();
  let end = new Date();
  return end.getTime() - start.getTime();
}

console.log(
  benchmark(function () {
    let x = 15;
    for (let i = 0; i < 10000000; i++) {
      x *= i;
    }
  })
);

// console.log(
  // benchmark(() => {
  //   let x = 15;
  //   for (let i = 0; i < 10000000; i++) {
  //     x *= i;
  //   }
  // })
// );
