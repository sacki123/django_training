{
  let data = 108;
  console.log(data);
}
console.log(data);
