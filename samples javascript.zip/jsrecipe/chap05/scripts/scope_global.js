var data1 = 'var variable';
let data2 = 'let variable';

console.log(data1);
console.log(window.data1);
console.log(data2);	
console.log(window.data2);