function sprintf(format, ...args) {
  for (let i = 0; i < args.length; i++) {
    let pattern = new RegExp('\\{' + (i) + '\\}', 'g');
    format = format.replace(pattern, args[i]);
  }
  return format;
}

console.log(sprintf('{0}を飼っています。名前は{1}です。', 'ハムスター', 'ウタ'));
