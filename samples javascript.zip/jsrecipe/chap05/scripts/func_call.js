var name = 'Global';
let data1 = { name: 'data1' };
let data2 = { name: 'data2' };

function showName() {
  console.log(this.name);
}

showName.call(null);
showName.call(data1);
showName.call(data2);
