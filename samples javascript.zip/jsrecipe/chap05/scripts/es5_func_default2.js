function getSquareArea(width, height) {
  if (width === undefined) {
    throw new Error('幅が指定されていません。');
  }
  if (height === undefined) {
    throw new Error('高さが指定されていません');
  }
  return width * height;
}

console.log(getSquareArea(2));
