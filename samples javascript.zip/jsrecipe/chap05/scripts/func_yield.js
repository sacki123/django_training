function* mygen() {
  yield '春が来た';
  yield* subgen();
  yield '花がさく';
}

function* subgen() {
  yield '山に来た';
  yield '里に来た';
  yield '野にも来た';
}

for (let str of mygen()) {
  console.log(str);
}
