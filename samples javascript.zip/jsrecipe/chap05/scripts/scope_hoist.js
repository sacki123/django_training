let scope = 'Global';

function show() {
  console.log(scope);
  let scope = 'Local';
  return scope;
}
show();
