function required(msg) {
  throw new Error(msg);
}

function getSquareArea(width = required('幅が指定されていません。'),
  height = required('高さが指定されていません。')) {
  return width * height;
}

console.log(getSquareArea(2));
