function* mygen() {
  yield 'おはよう';
  yield 'こんにちは';
  yield 'おやすみ';
}

let itr = mygen();
console.log(itr.next());
console.log(itr.next());
console.log(itr.next());
console.log(itr.next());
