function showPanel({
    path = 'content.html',
    height = 200,
    width = 300,
    resizable = true,
    draggable = true,
    modeless = false
  }) {
  console.log('path：'+ path);
  console.log('height：' + height);
  console.log('width：' + width);
  console.log('resizable：' + resizable);
  console.log('draggable：' + draggable);
  console.log('modeless：' + modeless);
};

showPanel({
  height: 250,
  width: 150,
  path: 'panel.html',
  resizable: false,
  draggable: false,
  modeless: true
});
