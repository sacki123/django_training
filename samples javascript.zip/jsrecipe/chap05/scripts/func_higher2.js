function benchmark(proc) {
  let start = new Date();
  proc();
  let end = new Date();
  return end.getTime() - start.getTime();
}

function p() {
  let x = 15;
  for (let i = 0; i < 10000000; i++) {
    x *= i;
  }
}

console.log(benchmark(p));
