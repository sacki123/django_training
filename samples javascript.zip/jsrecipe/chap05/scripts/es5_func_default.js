function getSquareArea(o_width, o_height) {
  if (o_width === undefined) { o_width = 1; }
  if (o_height === undefined) { o_height = 1; }
  return o_width * o_height;
}

console.log(getSquareArea(10, 5));
console.log(getSquareArea(10));
console.log(getSquareArea());
