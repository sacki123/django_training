function showPanel(args) {
  if (args.path === undefined) { args.path = 'content.html'; }
  if (args.height === undefined) { args.height = 200; }
  if (args.width === undefined) { args.width = 300; }
  if (args.resizable === undefined) { args.resizable = true; }
  if (args.draggable === undefined) { args.draggable = true; }
  if (args.modeless === undefined) { args.modeless = false; }
  console.log('path：'+ args.path);
  console.log('height：' + args.height);
  console.log('width：' + args.width);
  console.log('resizable：' + args.resizable);
  console.log('draggable：' + args.draggable);
  console.log('modeless：' + args.modeless);
}

showPanel({
  height: 250,
  width: 150,
  path: 'panel.html',
  resizable: false,
  draggable: false,
  modeless: true
});