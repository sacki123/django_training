console.log(Math.min([402, 35, 2, 169, 9]));
console.log(Math.min(...[402, 35, 2, 169, 9]));
console.log(Math.min.apply(null, [402, 35, 2, 169, 9]));
