if (true) {
  let x = 10;
}
 
console.log(x);

// switch(x) {
//   case 12:
//     let data = 'ダース';
//     break;
//   case 20:
//     let data = 'ケース';
//     break;
// }
