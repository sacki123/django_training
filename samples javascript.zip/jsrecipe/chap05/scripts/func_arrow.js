// let getSquareArea = (width, height) => {
//   return width * height;
// };

let getSquareArea = (width, height) => width * height;

console.log(getSquareArea(2, 3));
