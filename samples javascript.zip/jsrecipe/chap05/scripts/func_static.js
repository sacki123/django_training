console.log(getSquareArea(2, 3));

function getSquareArea(width, height) {
  return width * height;
}

// Functionコンストラクタ
// let getSquareArea = new Function(
//   'width', 'height', 'return width * height;');

// 関数リテラル
// let getSquareArea =
//   function (width, height) { return width * height; };
