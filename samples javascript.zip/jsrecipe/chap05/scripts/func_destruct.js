function print({ title }) {
  console.log(title);
}

let book = {
  title: '独習C# 新版',
  price: 3600,
  publsher: '翔泳社'
};

print(book);
