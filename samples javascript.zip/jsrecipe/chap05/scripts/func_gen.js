function* range(start, end) {
  for (let i = start; i < end; i++) {
    yield i;
  }
}

for (let num of range(10, 20)) {
  console.log(num);
}
