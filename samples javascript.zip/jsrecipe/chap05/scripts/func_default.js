function getSquareArea(width = 1, height = 1) {
  return width * height;
}

console.log(getSquareArea(2));
// console.log(getSquareArea(10, null));
// console.log(getSquareArea(10, undefined));

// function getSquareArea(width, height = width) {
//   return width * height;
// }
// console.log(getSquareArea(2, 3));
// console.log(getSquareArea(2));

// function getSquareArea(width = height, height = 1) {
//   return width * height;
// }
// console.log(getSquareArea());

// function getSquareArea(width = 1, height) {
//   return width * height;
// }
// console.log(getSquareArea(10));
