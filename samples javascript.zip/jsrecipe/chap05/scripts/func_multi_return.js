function getSumAverage(...values) {
  let result = 0;
  for (let value of values) {
    result += value;
  }
  return [result, result / values.length];
}

let [sum, average] = getSumAverage(3, 4, 5, 6);
// let [, average] = getSumAverage(3, 4, 5, 6);

console.log(sum);
console.log(average);
