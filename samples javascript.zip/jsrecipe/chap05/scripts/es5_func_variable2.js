function sprintf(format) {
  for (var i = 1; i < arguments.length; i++) {
    var pattern = new RegExp('\\{' + (i - 1) + '\\}', 'g');
    format = format.replace(pattern, arguments[i]);
  }
  return format;
}

console.log(sprintf('{0}を飼っています。名前は{1}です。', 'ハムスター', 'ウタ'));
