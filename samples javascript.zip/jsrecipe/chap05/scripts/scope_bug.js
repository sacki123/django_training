function hoge() {
  let x = z = 100;
}

hoge();
console.log(z);
