"use strict";

console.log(Math.ceil(4.56));
console.log(Math.ceil(-4.56));
console.log(Math.floor(4.56));
console.log(Math.floor(-4.56));
console.log(Math.round(4.56));
console.log(Math.round(-4.56));
console.log(Math.trunc(4.56));
console.log(Math.trunc(-4.56));