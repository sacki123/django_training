"use strict";

console.log(Math.pow(2, 3));
console.log(Math.pow(2, 3));
console.log(Math.sqrt(36));
console.log(Math.pow(36, 0.5));
console.log(Math.cbrt(64));