'use strict';

var str = 'なまむぎなまごめなまたまご';
console.log(str.includes('なま'));
console.log(str.startsWith('なま'));
console.log(str.endsWith('なま'));
console.log(str.includes('なま', 6));
console.log(str.startsWith('なま', 2));
console.log(str.endsWith('なま', 2));