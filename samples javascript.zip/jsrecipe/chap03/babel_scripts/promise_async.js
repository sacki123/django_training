'use strict';

var multi = function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(value) {
    var result1, result2, result3;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return runAsync(value);

          case 2:
            result1 = _context.sent;
            _context.next = 5;
            return runAsync(result1);

          case 5:
            result2 = _context.sent;
            _context.next = 8;
            return runAsync(result2);

          case 8:
            result3 = _context.sent;
            return _context.abrupt('return', result3);

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function multi(_x) {
    return _ref.apply(this, arguments);
  };
}();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function runAsync(value) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      if (typeof value === 'number') {
        resolve(value * 2);
      } else {
        reject(new Error(value + '\u306F\u6570\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002'));
      }
    }, 500);
  });
}

multi(15).then(function (response) {
  return console.log('\u6700\u7D42\u7D50\u679C\uFF3B' + response + '\uFF3D');
}).catch(function (error) {
  return console.log('\u5931\u6557\uFF3B' + error + '\uFF3D');
});