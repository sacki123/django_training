'use strict';

function runAsync(value) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      if (typeof value === 'number') {
        resolve(value * 2);
      } else {
        reject(new Error(value + '\u306F\u6570\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002'));
      }
    }, 500);
  });
}

Promise.race([runAsync(10), runAsync(15), runAsync(20)]).then(function (response) {
  return console.log('\u6210\u529F\uFF3B' + response + '\uFF3D');
}).catch(function (error) {
  return console.log('\u5931\u6557\uFF3B' + error + '\uFF3D');
});