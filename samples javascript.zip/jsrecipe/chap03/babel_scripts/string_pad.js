'use strict';

var str = 'WINGS';

console.log(str.padStart(10));
console.log(str.padStart(8, '*'));
console.log(str.padEnd(8, '*'));