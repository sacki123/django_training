'use strict';

var str = 'じゅげむ';
console.log(str.repeat(3));
console.log(str.repeat(0));
console.log(str.repeat(2.5));
console.log(str.repeat(-2));