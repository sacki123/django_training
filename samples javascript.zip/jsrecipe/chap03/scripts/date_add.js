let date = new Date(2018, 7, 1, 8, 16, 47);
console.log(date.toLocaleString());
date.setMonth(date.getMonth() + 10);
console.log(date.toLocaleString());
date.setDate(date.getDate() - 20);
console.log(date.toLocaleString());

// let date = new Date(2018, 7, 0);
// console.log(date.toLocaleString());
