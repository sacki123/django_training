let data = '+/,:;#$@?=%"&|';
console.log(encodeURI(data));
console.log(encodeURIComponent(data));
