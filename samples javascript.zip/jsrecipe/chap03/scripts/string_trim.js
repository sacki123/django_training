let str = '\n　\tWings プロジェクトは、執筆コミュニティです。     ';
console.log('「' + str.trim() + '」');
