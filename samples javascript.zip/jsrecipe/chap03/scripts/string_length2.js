let str = '𠮟られて';
let len = str.length;
let snum = str.split(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g).length - 1;
console.log(len - snum);
console.log([...'𠮟られて'].length);
