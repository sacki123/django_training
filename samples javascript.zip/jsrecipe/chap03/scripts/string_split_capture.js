let str = '桃栗3年柿8年';
console.log(str.split(/(\d)/));
