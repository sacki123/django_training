let str = 'WingsProject';
console.log(str.toLowerCase());
console.log(str.toUpperCase());

