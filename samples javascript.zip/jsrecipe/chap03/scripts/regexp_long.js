let tags = '<p><strong>WINGS</strong>サイト<a href="index.html"><img src="wings.jpg"></img></a></p>';
// let ex = /<.+>/g;
let ex = /<.+?>/g;
let result = tags.match(ex);
for (let i = 0; i < result.length; i++) {
  console.log(result[i]);
}
