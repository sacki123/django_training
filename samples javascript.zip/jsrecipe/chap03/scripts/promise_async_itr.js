async function* fetchIterator() {
  for (let i = 1; i <= 3; i++) {
    let result = await fetch(`article${i}.json`);
    yield result.json();
  }
}

async function showTitle() {
  for await (let data of fetchIterator()) {
    console.log(data.title);
  }
}

showTitle();