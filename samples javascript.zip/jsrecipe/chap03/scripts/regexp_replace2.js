let ex = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/gi;
let str = 'サンプルファイルはhttp://www.wings.msn.to/から入手できます。';
console.log(str.replace(ex, '<a href="$&">$&</a>'));
