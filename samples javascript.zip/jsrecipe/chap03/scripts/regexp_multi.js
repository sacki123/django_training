let ex = /^[A-Za-z]{1,}/gm;
// let ex = /^[A-Za-z]{1,}/g;
let str = 'Helloは、こんにちは。\nByeは、さようなら。';
let result = str.match(ex);
for (let i = 0; i < result.length; i++) {
  console.log(result[i]);
}
