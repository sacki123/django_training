let num = 123.456;
console.log(num.toFixed(2));
console.log(num.toFixed(5));
console.log(num.toPrecision(5));
console.log(num.toPrecision(8));
