let str = '𠮟られた';
console.log(str.match(/^.られた$/gu));
