let ex = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/gi;
let str1 = 'サンプルファイルはhttp://www.wings.msn.to/から入手できます。';
let str2 = 'ご質問は「掲示板」へお願いします！';
console.log(ex.test(str1));
console.log(ex.test(str2));
