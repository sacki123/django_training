let sub = 'もも';
let str = 'ももから生まれたももたろう';
console.log(str.replace(sub, '桃'));
