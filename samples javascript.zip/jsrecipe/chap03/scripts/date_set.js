let local = new Date();
local.setFullYear(2018);
local.setMonth(7);
local.setDate(1);
local.setHours(8);
local.setMinutes(16);
local.setSeconds(47);
local.setMilliseconds(555);

let local2 = new Date();
local2.setTime(1533450425000);

console.log(local);
console.log(local2);
