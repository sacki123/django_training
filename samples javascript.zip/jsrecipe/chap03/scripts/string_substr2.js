let str = 'こんにちは、あかちゃん';
console.log(str.substring(8, 6));
console.log(str.slice(8, 6));
