let str = 'こんにちは、あかちゃん';
console.log(str.substring(6, -3));
console.log(str.slice(6, -3));
