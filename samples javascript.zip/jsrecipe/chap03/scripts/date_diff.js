let date1 = new Date(2018, 7, 1);
let date2 = new Date(2018, 10, 15);
let diff = (date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24);
console.log(diff + '日の差です。');

