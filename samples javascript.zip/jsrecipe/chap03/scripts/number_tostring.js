let num = 255;
console.log(num.toString(2));
console.log(num.toString(16));
console.log(num.toString(36));
