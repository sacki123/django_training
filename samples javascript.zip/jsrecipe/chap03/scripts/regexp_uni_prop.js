let str = 'さくら色';
console.log(str.match(/\p{sc=Hiragana}/gu));