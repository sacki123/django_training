let site = '<p>サポートサイト<a href="http://www.wings.msn.to/">http://www.wings.msn.to/</a></p>';
let ex = /<a href="(?<link>.+?)">\k<link><\/a>/;
console.log(site.match(ex)[0]);
