console.log('Wings Project\n執筆コミュニティ'.split(/[\s\n]/));
console.log('Wings Projectは執筆コミュニティ'.split('は'));
console.log('Wings Project'.split(''));
console.log('Wings Project'.split());
console.log('Wings Project\n執筆コミュニティ'.split(/[\s\n]/, 2));
