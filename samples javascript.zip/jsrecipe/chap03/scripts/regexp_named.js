let ex = /(?<localName>[a-z0-9.!#$%&'*+/=?^_{|}~-]+)@(?<domain>[a-z0-9-]+(?:\.[a-z0-9-]+)*)?/i;
let mail = 'メールアドレスは、wings@example.comです。';
let result = mail.match(ex);
// let result = ex.exec(mail);
console.log(`仕事用アドレスは、${result.groups.domain}の${result.groups.localName}です。`);
