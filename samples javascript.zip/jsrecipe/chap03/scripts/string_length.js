let song1 = 'ともだち賛歌';
let song2 = '𠮟られて';
console.log(song1.length);
console.log(song2.length);
