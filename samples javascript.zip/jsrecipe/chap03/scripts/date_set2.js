let utc = new Date();
utc.setUTCFullYear(2018);
utc.setUTCMonth(7);
utc.setUTCDate(1);
utc.setUTCHours(8);
utc.setUTCMinutes(16);
utc.setUTCSeconds(47);
utc.setUTCMilliseconds(555);

console.log(utc);
