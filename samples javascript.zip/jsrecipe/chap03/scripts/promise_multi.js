function runAsync(value) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (typeof value === 'number') {
        resolve(value * 2);
      } else {
        reject(new Error(`${value}は数値ではありません。`));
      }
    }, 500);
  });
}

runAsync(15)
  .then(response => runAsync(response))
  .then(response => runAsync(response))
  .then(response => console.log(`最終結果［${response}］`))
  .catch(error => console.log(`失敗［${error}］`));
