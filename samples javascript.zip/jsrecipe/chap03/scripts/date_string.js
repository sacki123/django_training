let date = new Date(2018, 7, 1, 8, 16, 47, 555);
console.log(date.toLocaleString());
console.log(date.toLocaleDateString());
console.log(date.toLocaleTimeString());
console.log(date.toUTCString());
console.log(date.toISOString());
console.log(date.toDateString());
console.log(date.toTimeString());
console.log(date.toJSON());
