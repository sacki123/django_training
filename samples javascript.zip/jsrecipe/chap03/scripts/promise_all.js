function runAsync(value) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (typeof value === 'number') {
        resolve(value * 2);
      } else {
        reject(new Error(`${value}は数値ではありません。`));
      }
    }, 500);
  });
}

Promise.all([
  runAsync(10),
  runAsync(15),
  runAsync(20),
])
  .then(response => console.log(`成功［${response}］`))
  .catch(error => console.log(`失敗［${error}］`));
