let str = 'こんにちは、あかちゃん';
console.log(str.substring(6));
console.log(str.substring(6, 8));
console.log(str.slice(6, 8));
console.log(str.substr(6, 2));
console.log(str.charAt(6));
