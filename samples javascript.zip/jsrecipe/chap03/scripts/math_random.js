let min = 100;
let max = 200;
console.log(Math.floor(Math.random() * (max - min + 1)) + min);
console.log(Math.floor(Math.random() * 100) + 1);
