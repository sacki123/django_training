function runAsync(value) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (typeof value === 'number') {
        resolve(value * 2);
      } else {
        reject(new Error(`${value}は数値ではありません。`));
      }
    }, 500);
  });
}

async function multi(value) {
  let result1 = await runAsync(value);
  let result2 = await runAsync(result1);
  let result3 = await runAsync(result2);
  return result3;
}

multi(15)
  .then(response => console.log(`最終結果［${response}］`))
  .catch(error => console.log(`失敗［${error}］`));
