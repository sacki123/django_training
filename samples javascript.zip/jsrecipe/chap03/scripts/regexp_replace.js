let ex = /(0\d{1,4})-(\d{1,4})-(\d{3,4})/gi;
let str = 'お問い合わせは、000-000-0000まで。休日は、0111-11-1111。';
let result = str.replace(ex, '$1($2)$3');
console.log(result);
