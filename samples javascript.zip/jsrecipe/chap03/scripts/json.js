let str = '{ "title": "Angularプログラミング", "price": 3700 }';
let jobj = JSON.parse(str);
console.log(jobj.title);
