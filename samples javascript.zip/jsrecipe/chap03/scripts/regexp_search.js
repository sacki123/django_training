let ex = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/gi;
let str1 = 'サンプルファイルはhttp://www.wings.msn.to/から入手できます。';
let str2 = 'ご質問は「掲示板」へお願いします！';
console.log(str1.search(ex));
console.log(str2.search(ex));
