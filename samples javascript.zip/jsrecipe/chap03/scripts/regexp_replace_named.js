let ex = /(?<area>0\d{1,4})-(?<city>\d{1,4})-(?<sub>\d{3,4})/gi;
let str = 'お問い合わせは、000-000-0000まで。休日は、0111-11-1111。';
let result = str.replace(ex, '$<area>($<city>)$<sub>');

console.log(result);
