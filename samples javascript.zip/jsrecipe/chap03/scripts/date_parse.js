console.log(Date.parse('2018-12-15'));
console.log(Date.parse('2018-12-15T18:15:00'));
console.log(Date.parse('2018-12-15T18:15:00+0900'));
console.log(Date.parse('Sat, 15 Dec 2018 18:15:00+0900'));
console.log(Date.UTC(2018, 7, 1, 8, 16, 47, 555));
console.log(Date.now());
