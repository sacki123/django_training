let ex = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/gi;
let str = 'サンプルファイルはHTTP://www.Wings.msn.to/から入手できます。';
let result = str.replace(ex, function (match, p1, p2, p3, offset, string) {
  return match.toLowerCase();
});
console.log(result);
