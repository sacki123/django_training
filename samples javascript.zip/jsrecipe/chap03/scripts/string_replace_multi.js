let str = 'ももから生まれたももたろう';
console.log(str.split('もも').join('桃'));
