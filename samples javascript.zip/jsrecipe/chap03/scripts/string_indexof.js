let str = 'もももすももも';
console.log(str.indexOf('もも'));
console.log(str.lastIndexOf('もも'));
console.log(str.indexOf('もも', 2));
console.log(str.lastIndexOf('もも', 2));
console.log(str.indexOf('ももかん'));
