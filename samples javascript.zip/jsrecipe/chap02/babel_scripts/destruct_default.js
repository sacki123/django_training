'use strict';

var member = { mid: 'y001', name: '山田太郎', age: 40 };
var age = member.age,
    name = member.name,
    _member$nickname = member.nickname,
    nickname = _member$nickname === undefined ? 'やまちゃん' : _member$nickname;


console.log(nickname);