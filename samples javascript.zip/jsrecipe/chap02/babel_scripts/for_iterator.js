'use strict';

var data = ['JavaScript', 'CoffeeScript', 'TypeScript'];
var itr = data[Symbol.iterator]();
var d = void 0;
while (d = itr.next()) {
  if (d.done) {
    break;
  }
  console.log(d.done);
  console.log(d.value);
}