"use strict";

var data = [85, 625, 124, 830, 227];
var x0 = data[0],
    x1 = data[1],
    x2 = data[2],
    last = data.slice(3);

console.log(x0);
console.log(x1);
console.log(x2);
console.log(last);