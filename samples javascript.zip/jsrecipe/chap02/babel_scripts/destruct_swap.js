"use strict";

var x = 111;
var y = 999;
var _ref = [y, x];
x = _ref[0];
y = _ref[1];

console.log(x, y);

// ES2015以前の場合
// var x = 111;
// var y = 999;
// var tmp = x;
// x = y;
// y = tmp;
// console.log(x, y);