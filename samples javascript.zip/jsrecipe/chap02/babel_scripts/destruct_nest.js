'use strict';

var member = {
  mid: 'y001', name: '山田太郎', age: 40,
  other: { company: 'WINGS', photo: 'y001.jpg' }
};
var name = member.name,
    other = member.other,
    company = member.other.company;


console.log(name);
console.log(other);
console.log(company);