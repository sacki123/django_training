"use strict";

var data = [85, 625, 124, 830, 227];
var x0 = data[0],
    x1 = data[1],
    x2 = data[2];
var y0 = data[0],
    y1 = data[1],
    y2 = data[2],
    y3 = data[3],
    y4 = data[4],
    y5 = data[5];


console.log(y5);