'use strict';

var member = { mid: 'y001', name: '山田太郎', age: 40 };
var age = member.age,
    name = member.name,
    birth = member.birth;


console.log(name);
console.log(age);
console.log(birth);