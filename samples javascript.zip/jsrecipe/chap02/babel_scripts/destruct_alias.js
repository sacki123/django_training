'use strict';

var member = { mid: 'y001', name: '山田太郎', age: 40 };
var author = member.name,
    old = member.age;


console.log(author);
console.log(old);