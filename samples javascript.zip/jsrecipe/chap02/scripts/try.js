try {
  console.log(data);
} catch (ex) {
  console.log(ex.message);
} finally {
  console.log('コードが終了しました！');
}
