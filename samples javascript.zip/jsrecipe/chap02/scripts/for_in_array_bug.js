let data = ['JavaScript', 'CoffeeScript', 'TypeScript'];
Array.prototype.hoge = function () { /* ... */ };

for (let i in data) {
  console.log(data[i]);
}
