console.log(true == 1);
console.log('1.414E3' == 1414);
console.log('0x10' == 16);
