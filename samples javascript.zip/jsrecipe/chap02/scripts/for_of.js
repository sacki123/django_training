let data = ['JavaScript', 'CoffeeScript', 'TypeScript'];
for (let value of data) {
  console.log(value);
}
