let blood = 'O';

switch (blood) {
  case 'A':
    console.log('A型です。');
    break;
  case 'B':
    console.log('B型です。');
    break;
  case 'O':
    console.log('O型です。');
    break;
  case 'AB':
    console.log('AB型です。');
    break;
  default:
    console.log('不明です。');
    break;    
}
