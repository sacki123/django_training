let name = '';
name = name || '権兵衛';
// name = (name === undefined ? '権兵衛' : name);
console.log(name);
