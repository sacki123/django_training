let member = { mid: 'y001', name: '山田太郎', age: 40 };
let { age, name, nickname = 'やまちゃん' } = member;

console.log(nickname);
