function getCircleArea(radius) {
  if (typeof (radius) !== 'number' || radius <= 0) {
    throw new TypeError('引数radiusは正の数値でなければいけません。');
  }
  return radius * radius * Math.PI;
}

try {
  console.log(getCircleArea(-3));
} catch (ex) {
  console.error(ex.message);
}
