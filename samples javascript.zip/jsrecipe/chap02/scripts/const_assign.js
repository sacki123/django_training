// const tax = 1.08;
// tax = 1.1;

const data = ['JavaScript', 'CoffeeScript', 'TypeScript'];
// data = ['Vue.js', 'TypeScript', 'ECMAScript'];
data[0] = 'JS';

console.log(data);
