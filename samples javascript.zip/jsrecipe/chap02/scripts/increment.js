let i = 10;
let j = i++;
console.log(i);
console.log(j);

// let i = 10;
// let j = ++i;
// console.log(i);
// console.log(j);
