console.log('YAMADA.' + 'Yoshihiro');
console.log('10' + '11');
console.log(8 + '5');
let today = new Date();
console.log(100 + today);
