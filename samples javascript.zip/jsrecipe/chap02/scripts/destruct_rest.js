let data = [85, 625, 124, 830, 227];
let [x0, x1, x2, ...last] = data;
console.log(x0);
console.log(x1);
console.log(x2);
console.log(last);
