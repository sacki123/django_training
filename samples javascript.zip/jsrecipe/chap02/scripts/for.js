for (let i = 2; i < 5; i++) {
  console.log('iは' + i);
}
