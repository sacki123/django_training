let i = 10;
let j = 10;
console.log(i == j);

let m = ['赤', '黄', '青'];
let n = ['赤', '黄', '青'];
console.log(m == n);
