let point = 85;

if (point >= 80)
  console.log('合格です！');
else if (point >= 60)
  console.log('あともう少し');
else
  console.log('出直しましょう');
