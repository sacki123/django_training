let member = {
  mid: 'y001', name: '山田太郎', age: 40,
  other: { company: 'WINGS', photo: 'y001.jpg' }
};
let { name, other, other: { company } } = member;

console.log(name);
console.log(other);
console.log(company);
