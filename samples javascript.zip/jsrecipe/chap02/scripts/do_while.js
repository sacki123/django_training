let i = 2;

do {
  console.log('iは' + i);
  i++;
} while (i < 5);
