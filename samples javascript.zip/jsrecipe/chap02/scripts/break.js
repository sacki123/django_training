let data = ['計量', 'こねる', 'まるめる', '', 'ガス抜き', '成形', '', '焼く'];

for (let i = 0; i < data.length; i++) {
  if (data[i] === '') { break; }
  console.log(data[i]);
}
