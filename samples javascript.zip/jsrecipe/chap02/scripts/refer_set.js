let i = 10;
let j = i;
i = 15;
console.log(j);

let m = ['赤', '黄', '青'];
let n = m;
m[2] = '緑';
console.log(n);
