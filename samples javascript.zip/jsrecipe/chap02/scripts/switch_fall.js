let grade = '1級';

switch (grade) {
  case '特級':
  case '1級':
  case '2級':
    console.log('上級者です。');
    break;
  case '3級':
  case '4級':
  case '5級':
    console.log('上級者ではありません。');
    break;    
}
