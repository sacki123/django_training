let data = ['JavaScript', 'CoffeeScript', 'TypeScript'];

for (let i in data) {
  console.log(data[i]);
}
