let math = 100;
let science = 90;

if (math === 100) 
  if (science === 100) console.log('どちらも100点です！');
else
  console.log('数学は100点ではありません。');
