let member = { mid: 'y001', name: '山田太郎', age: 40 };
let { age, name, birth } = member;

console.log(name);
console.log(age);
console.log(birth);
