let data = [
  ['緑茶', 'コーヒー'],
  ['おにぎり', 'サンドイッチ'],
  ['肉じゃが', 'からあげ'],
  ['まんじゅう', 'ケーキ'],
];

nest:
for (let i = 0; i < data.length; i++) {
  for (let j = 0; j < data[i].length; j++) {
    if (data[i][j] === 'からあげ') { break nest; }
    console.log(data[i][j]);
  }
  console.log('---------------------');
}
