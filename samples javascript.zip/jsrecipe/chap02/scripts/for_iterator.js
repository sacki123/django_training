let data = ['JavaScript', 'CoffeeScript', 'TypeScript'];
let itr = data[Symbol.iterator]();
let d;
while (d = itr.next()) {
  if (d.done) { break; }
  console.log(d.done);
  console.log(d.value);
}
