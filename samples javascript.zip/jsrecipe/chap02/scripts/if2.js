let point = 85;

if (point >= 80) {
  console.log('合格です！');
}
