console.log(0.1 * 3);
console.log(((0.1 * 10) * 3) / 10);
