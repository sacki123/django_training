let data = [85, 625, 124, 830, 227];
let [x0, x1, x2] = data;
let [y0, y1, y2, y3, y4, y5] = data;

console.log(x0);
console.log(x1);
console.log(x2);
console.log(y0);
console.log(y1);
console.log(y2);
console.log(y3);
console.log(y4);
console.log(y5);
