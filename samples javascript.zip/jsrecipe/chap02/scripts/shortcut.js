let i = 1;
if (i === 1) { console.log('変数iは1です。'); }
i === 1 && console.log('変数iは1です。');

