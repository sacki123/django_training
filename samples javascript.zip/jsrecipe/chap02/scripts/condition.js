let point = 75;
console.log((point >= 70) ? 'Clear！' : 'Failed...');
