let member = { mid: 'y001', name: '山田太郎', age: 40 };
let { mid, ...other } = member;
console.log(mid);
console.log(other);
