let obj = { name: 'ソメイヨシノ', type: 'さくら', price: 2500 };

for (let i in obj) {
  console.log(i + 'は、' + obj[i]);
}
