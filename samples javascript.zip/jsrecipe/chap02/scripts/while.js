let i = 2;

while (i < 5) {
  console.log('iは' + i);
  i++;
}
