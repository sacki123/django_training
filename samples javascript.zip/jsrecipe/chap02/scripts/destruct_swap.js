let x = 111;
let y = 999;
[x, y] = [y, x];
console.log(x, y);


// ES2015以前の場合
// var x = 111;
// var y = 999;
// var tmp = x;
// x = y;
// y = tmp;
// console.log(x, y);
