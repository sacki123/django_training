import os
import datetime
import json
import jaconv
import xlwt
from gimei import Gimei
from xlrd import open_workbook
from xlwt import Workbook
from faker import Faker, Factory

def read_excel(path_excel):
    data = []
    wb = open_workbook(path_excel)
    ws= wb.sheet_by_index(0)
    sheet_rows = ws.nrows
    for row in range(sheet_rows):
        data.append(ws.row_values(row))
    return data

def read_json(path_json):
    with open(path_json, encoding='utf-8') as f:
        json_config = json.load(f)  
    return json_config

def validate_date(value):
    if value < 10:
        value = "0" + str(value)
    else:
        value = str(value)
    return value

def create_birth_day(date):
    while True:
        birth_day = fake.date_of_birth(tzinfo=None, minimum_age=20, maximum_age=90)
        y = str(birth_day.year)
        if birth_day.month < 10:
            m = "0" + str(birth_day.month)
        else:
            m = str(birth_day.month)
        if birth_day.day < 10:
            d = "0" + str(birth_day.day)
        else:
            d = str(birth_day.day)  
        birth_day = int(y + m + d)
        if birth_day != date:
            break   
    return birth_day

def create_kanji_name(name):
    while True:
        g = Gimei()
        create_name = g.name
        name_kanji = create_name.kanji
        if len(name_kanji) < 10 and name_kanji != name:
            break
    if len(name) > len(name_kanji):
        loop = len(name) - len(name_kanji)
        name_kanji = name_kanji + (loop * "\u3000") 
    return jaconv.h2z(name_kanji, digit=True, ascii=True)

def create_kana_name(name):
    while True:
        g = Gimei()
        create_name = g.name
        name_kana = jaconv.z2h(create_name.katakana, digit=True, ascii=True)
        if len(name_kana) < 20 and name_kana != name:
            break
    return name_kana

def create_zipcode(zipcode):
    while True:
        zc = fake.zipcode()
        if len(zc) <= 8 and zc != zipcode:
            break
    return zc

def create_address(address):
    while True:
        ad = fake.address()
        if len(ad) <= 60 and ad != address:
            break  
    if len(address) > len(ad):
        loop = len(address) - len(ad)
        ad = ad + (loop * "\u3000")
    else:
        ad = ad[0:30]           
    return jaconv.h2z(ad, digit=True, ascii=True)

def execute(excels, path_input, json):
    path_json = os.path.join(os.path.dirname(__file__), json)
    data_json = read_json(path_json)
    for excel in excels:
        path_output = os.path.join(os.path.dirname(__file__), 'output/') 
        replace_data = list(data_json.keys())
        data_excel = read_excel(os.path.join(path_input, excel))
        for key, value in enumerate(data_excel[0]):
            if value in replace_data:
                if data_json.get(value)['type'] == 9 and data_json.get(value)['value'] == 'date':
                    for index in range(1, len(data_excel)):
                        data_excel[index][key] = create_birth_day(data_excel[index][key])
                if data_json.get(value)['type'] == 'X':
                    if data_json.get(value)['value'] == 'num':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = str(f.random_int(12345678, 87654321))
                    if data_json.get(value)['value'] == 'kana':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = create_kana_name(data_excel[index][key])
                    if data_json.get(value)['value'] == 'zipcode':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = create_zipcode(data_excel[index][key])
                elif data_json.get(value)['type'] == 'N':
                    if data_json.get(value)['value'] == 'kanji':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = create_kanji_name(data_excel[index][key])
                    if data_json.get(value)['value'] == 'address':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = create_address(data_excel[index][key])
                    if data_json.get(value)['value'] == 'isha_name':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = create_kanji_name(data_excel[index][key])   
                    if data_json.get(value)['value'] == 'isha_name_new':
                        for index in range(1, len(data_excel)):
                            data_excel[index][key] = create_kanji_name(data_excel[index][key])         
        name_excel = excel.split('.')
        date_now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        wb = Workbook()
        ws = wb.add_sheet(name_excel[0])
        excel_out = (path_output + name_excel[0] + '_' + date_now + '.' + name_excel[1])
        style = xlwt.Style.easyxf("""align: wrap no; font: name ＭＳ Ｐゴシック""")
        for col_index, value in enumerate(data_excel[0]):
            ws.write(0, col_index, value, style)
            ws.col(col_index).width = 2350
        for row_index, row in enumerate(data_excel):
            if row_index == 0:
                continue
            for col_index, value in enumerate(row):
                ws.write(row_index, col_index, value, style)
        wb.save(excel_out)
        print("Success")
fake = Faker('ja_JP')
f = Factory.create('ja_JP')        
path_input_SK = os.path.join(os.path.dirname(__file__),'input','鍼灸')
path_input_JS = os.path.join(os.path.dirname(__file__),'input','柔整')
excels_SK = os.listdir(path_input_SK)
excels_JS = os.listdir(path_input_JS)
if excels_SK:
    execute(excels_SK, path_input_SK, 'config_SK.json')
if excels_JS:
    execute(excels_JS, path_input_JS, 'config_JS.json')    