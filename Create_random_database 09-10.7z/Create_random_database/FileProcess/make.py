import os
import csv
import sys
import uuid
import mysql.connector
from xlrd import open_workbook
from datetime import datetime
from faker import Faker, Factory
from RandomData import CreateData as h

path= os.listdir(os.path.dirname(os.path.dirname(__file__)) + "/input/")
path_file = os.path.dirname(os.path.dirname(__file__)) + "/input/" + path[0]
wb = ""
def getconnection():
    con = mysql.connector.connect(host = sys.argv[1], database = sys.argv[2], user = sys.argv[3], password = sys.argv[4])
    return con


def read_sheet_name(path_file):
    global wb
    wb = open_workbook(path_file)


def create_dict_key(dic_main):
    name_sheet = wb.sheet_names()
    for j in name_sheet: 
        if (j == "Summary" or j == "Entity List" or j == "Domain List"):
            continue   
        dic_main[j] = {"KEY":""}    
        worksheet = wb.sheet_by_name(j)
        rows = worksheet.nrows
        for i in range(13,rows):
            if worksheet.cell(i,0).value == "Relationship info (PK Side)":
                if i+2 < rows and worksheet.cell(i+2,2).value != "":
                    lst_did_relation = list()
                    lst_rid_relation = list()
                    for j1 in range(0, rows - i-2):
                        lst_did_table = list()
                        lst_rid_table = list()
                        if worksheet.cell(j1+i+2,2).value == "did":
                            lst_did_table.append(worksheet.cell(j1+i+2,4).value)
                            lst_did_table.append(worksheet.cell(j1+i+2,6).value)
                            lst_did_relation.append(lst_did_table)
                        elif worksheet.cell(j1+i+2,2).value == "rid":     
                            lst_rid_table.append(worksheet.cell(j1+i+2,4).value)
                            lst_rid_table.append(worksheet.cell(j1+i+2,6).value)
                            lst_rid_relation.append(lst_rid_table)  
                    dic_relation = dict()
                    dic_forein_key = dict()
                    dic_primary_key = dict()
                    dic_forein_key["did"] = lst_did_relation
                    dic_primary_key["rid"] = lst_rid_relation
                    dic_primary_key.update(dic_forein_key)
                    dic_relation["KEY"] = dic_primary_key
                    dic_main[j].update(dic_relation)
                    break
                else:
                    dic_main[j] = {"KEY":""}


def create_dict_columninfo(dic_main):
    tg2 = ""
    tg3 = ""
    name_sheet = wb.sheet_names()
    for j in name_sheet:
        dic_temp1 = dict()
        dic_temp2 = dict()
        worksheet = wb.sheet_by_name(j)
        rows = worksheet.nrows
        if (j == "Summary" or j == "Entity List" or j == "Domain List"):
            continue
        for i in range(13,rows):
            if worksheet.cell(i,1).value != "":
                tg2 = worksheet.cell(i,2).value
                tg3 = worksheet.cell(i,3).value
                dic_temp1[tg2] = tg3
            else:
                break    
        dic_temp2["rid"] = dic_temp1
        dic_main[j].update(dic_temp2)


def create_data_layout(dic_main, loop):
    name_sheet = wb.sheet_names()
    for j in name_sheet:
        if (j == "Summary" or j == "Entity List" or j == "Domain List"):
            continue
        lst = list()
        dic_temp = dict()
        lst1 = list(dic_main[j]["rid"].keys())
        for i in range(0,loop):
            j1 = 0
            dic1 = dict()
            for j1 in range(0,len(lst1)):
                dic1[lst1[j1]] = ""
            lst.append(dic1) 
        dic_temp["Data"]  = lst
        dic_main[j].update(dic_temp)   
    

def create_data(dic_main, loop):
    name_sheet = wb.sheet_names()
    for j in name_sheet:
        if (j == "Summary" or j == "Entity List" or j == "Domain List"):
            continue
        for i in range(0,loop):
            j1 = 0
            for j1, value in dic_main[j]["rid"].items():
                if j1 == "did":
                    dic_main[j]["Data"][i]["did"] = h.dispatch_if(j1, value)
                    if dic_main[j]["KEY"] != "" and len(dic_main[j]["KEY"]["did"]) > 0:
                        key_did = dic_main[j]["KEY"]["did"]
                        j2 = 0
                        for j2 in key_did:
                            dic_main[j2[0]]["Data"][i][j2[1]] = dic_main[j]["Data"][i]["did"]          
                elif j1 == "rid":
                    dic_main[j]["Data"][i]["rid"] = h.dispatch_if(j1, value)
                    if dic_main[j]["KEY"] != "" and len(dic_main[j]["KEY"]["rid"]) > 0:
                        key_rid = dic_main[j]["KEY"]["rid"]
                        j3 = 0
                        for j3 in key_rid:
                            dic_main[j3[0]]["Data"][i][j3[1]] = dic_main[j]["Data"][i]["rid"]        
                elif dic_main[j]["Data"][i][j1] == "":
                    dic_main[j]["Data"][i][j1] = h.dispatch_if(j1, value)
                elif dic_main[j]["Data"][i][j1] != "":
                    continue       

    
def fill_data(dic_main):
    try:
        name_sheet = wb.sheet_names()  
        con = getconnection()
        cursor = con.cursor()      
        for j in name_sheet:
            if (j == "Summary" or j == "Entity List" or j == "Domain List"):
                continue
            lst = list()    
            str_value = ""
            str_key = ""     
            tg = dic_main[j]["Data"]
            for key in dic_main[j]["rid"].keys():
                str_key = str_key + key + "," 
                str_value = str_value + '%s,'
            str_key = str_key[0:len(str_key)-1]         
            str_value = str_value[0:len(str_value)-1]  
            str_insert = "insert into "+j+"("     
            for i in tg:  
                lst.append(tuple(i.values()))       
            str_insert = str_insert + str_key + ") values(" + str_value + ")"  
            cursor.executemany(str_insert,lst)
            con.commit()
    except mysql.connector.Error as e:
        print("Error {}".format(e))
        con.rollback()
    finally:
        cursor.close()
        con.close()  

def main(dic_main, loop):
    read_sheet_name(path_file)
    create_dict_key(dic_main)
    create_dict_columninfo(dic_main)
    create_data_layout(dic_main, loop)
    create_data(dic_main, loop)
    fill_data(dic_main)             