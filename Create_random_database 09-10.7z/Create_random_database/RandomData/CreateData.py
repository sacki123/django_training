from datetime import datetime
import string
import random
import uuid
import time
from faker import Faker,Factory

fake = Faker('ja_JP')
f = Factory.create('ja_JP')

domains = [ "hotmail.com", "gmail.com", "aol.com", "mail.com" , "mail.kz", "yahoo.com"]
letters = list(string.ascii_lowercase)

def dispatch_if(x,y):
    if x == 'rid' and y == 'CHAR(40)':
        z = get_key_rid()
        return z
    elif x == 'did' and y == 'CHAR(40)':
        z = get_key_rid()
        return z   
    elif x == 'rloginid' and y == 'CHAR(40)':
        z = get_key_did()
        return z    
    elif y == 'CHAR(40)':
        z = get_key_rid()
        return z     
    elif y == 'TIMESTAMP':
        z = get_timestamp()
        return z
    elif y == 'DATETIME':
        z = get_timestamp()
        return z    
    elif x == 'apply_start_date' and y == 'DATE':
        z = get_date()
        return z
    elif y == 'DATE':
        z = get_date()
        return z    
    elif x == 'apply_end_date' and y == 'DATE':
        z = get_date()
        return z    
    elif ((x == 'delete_flag' or x == 'manager_authority_flag' or x == 'flat_fee_add_flag') and y == 'TINYINT'):
        z = get_flag()
        return z 
    elif x == 'revision' and y == 'INT':
        z = get_flag()
        return z    
    elif (('last_name' in x or 'last_name_kana' in x) and y == 'TINYTEXT'): 
        z = get_name()
        return z
    elif (('first_name' in x or 'first_name_kana' in x) and y == 'TINYTEXT'): 
        z = get_name()
        return z
    elif x == 'display_name' and y == 'TINYTEXT':
        z = get_name()
        return z  
    elif 'zip_code' in x and y == 'TINYTEXT':
        z = get_zipcode()
        return z  
    elif (('phone' in x or 'fax' in x)  and y == 'TINYTEXT'):
        z = get_phone()
        return z 
    elif (('city' in x)  and y == 'TINYTEXT'):
        z =  get_city()
        return z 
    elif (('town' in x)  and y == 'TINYTEXT'):
        z = get_town()
        return z  
    elif (('street' in x)  and y == 'TINYTEXT'):
        z = get_chome()
        return z     
    elif (('address' in x)  and y == 'TINYTEXT'):
        z = get_address()
        return z  
    elif y == 'VARCHAR(255)':
        z = get_unknow(x)
        return z      
    elif y == 'TINYTEXT':
        z = get_unknow(x)
        return z
    elif y == 'TEXT':
        z = get_unknow(x)
        return z    
    elif y == 'VARCHAR(42)':
        z = get_varchar(42)
        return z  
    elif y == 'LONGTEXT':
        z = get_unknow(x)
        return z 
    elif y == 'CHAR(10)':
        z = get_tinytext()
        return z     
    elif y == 'CHAR(31)':
        z = get_char(31)
        return z     
    elif y == 'INT':
        z = get_int(5)
        return z   
    elif y == 'TINYINT':
        z = get_tinyint()
        return z   
    elif y == 'INT UNSIGNED':
        z = get_int(6)
        return z
    elif y == 'TINYINT UNSIGNED':
        z = get_int(3)
        if z < 0:
            z = z*(-1)
        return z  
    elif y == 'FLOAT UNSIGNED':
        z = get_decimal(64,2)
        if z < 0:
            z = z*(-1)
        return z      
    elif y == 'FLOAT(64,2)':
        z = get_decimal(64,2)
        if z < 0:
            z = z*(-1)
        return z  
    elif y == 'DECIMAL(13,2)':
        z = get_decimal(13,2)
        if z < 0:
            z = z*(-1)
        return z 
    elif y == 'bigint':
        z = get_int(12)
        return z    
    elif y == 'TIME':
        z = get_time()
        return z  
    elif y == 'YEAR':
        z = get_year()
        return z  
    elif y == 'MONTH':
        z = get_month()
        return z  
    elif y == 'DAY':
        z = get_day()
        return z 
    elif y == 'MAIL':
        z = get_email()
        return z    
    else:
        return get_tinytext()    

def get_one_random_domain(domains):
        return domains[random.randint( 0, len(domains)-1)]

def get_one_random_name(letters):
    email_name = ""
    for i in range(7):
        email_name = email_name + letters[random.randint(0,11)]
    return email_name

def generate_random_emails():
    for i in range(0,10):
        one_name = str(get_one_random_name(letters))
        one_domain = str(get_one_random_domain(domains))
        return one_name  + "@" + one_domain

def generate(col_type):
    if '('in col_type: function_name = "gen_" + col_type[:col_type.find("(")]
    else: function_name = "gen_" + col_type 
    try: 
        variable = [int(i) for i in col_type[col_type.find("(")+1:col_type.find(")")].split(',')]
    except: variable = ""
    random.seed(time.time())
    return globals()[function_name](*variable)

def get_phone():
    return f.phone_number()

def get_zipcode():
    return f.zipcode()

def get_address():
    return f.address()

def get_city():
    return f.city()

def get_town():
    return f.town()

def get_chome():
    return f.chome()

def get_decimal(p,s):
    return round(random.uniform(-10**(p-s)+1,10**(p-s)-1),s)

def get_tinyint():
    return random.randint(0,127)

def get_email():
    return f.mail()

def get_int(n):
    return random.randint(0,10**n-1)

def get_year():
    return random.randint(1970, 1999)

def get_month():
    return random.randint(1, 12)

def get_day():
    return random.randint(1, 31)

def get_time():
    return f.time()

def get_timestamp():
    year = random.randint(1970, 2017)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)
    second = random.randint (0,59)
    return datetime(year, month, day, hour, minute, second)

def get_date():
    year = random.randint(1970, 2017)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return datetime.date(datetime(year, month, day))

def get_datetime():
    year = random.randint(1970, 2017)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)
    second = random.randint (0,59)
    return datetime(year, month, day, hour, minute, second)

def get_char(n):
    text = fake.text().replace('\r', ' ').replace('\n', ' ')
    return text if len(text) < n else text[:n]

def get_varchar(n):
    text = fake.text().replace('\r', ' ').replace('\n', ' ')
    return text if len(text) < n else text[:n]

def get_mediumtext():
    max_char = 15
    text = fake.text().replace('\r', ' ').replace('\n', ' ')
    return text if len(text) < max_char else text[:max_char]

def get_text():
    max_char = 100
    text = fake.text().replace('\r', ' ').replace('\n', ' ')
    return text if len(text) < max_char else text[:max_char]

def get_tinytext():
    max_char = 10
    text = fake.text().replace('\r', ' ').replace('\n', ' ')
    return text if len(text) < max_char else text[:max_char]

def get_unknow(x):
    text = "テスト_"+x
    return text
def get_name():
    return f.name()

def get_key_rid():
    return str(uuid.uuid4())

def get_key_did():
    return str(uuid.uuid4().hex)

def get_money():
    return int(str(random.randint(10,999))+'00')

def get_flag():
    return random.randint(0,1)   

def get_loginid():
    return "id00"+str(random.randint(1,999))

