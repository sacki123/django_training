import re
import traceback
from logging import getLogger
import sys
import os

from FileProcess import make as p
log = getLogger(__name__)

if __name__ == "__main__":
    try:
        log.debug(sys.argv)
        dic_main = dict()
        loop = int(sys.argv[5])
        count =  1000
        d = loop // count
        f = loop % count
        if loop <= count:
            p.main(dic_main, loop)
        elif loop > count:  
            for i in range(d):
                p.main(dic_main, count)
                dic_main.clear()
            p.main(dic_main, f)    
    except:
        log.error(traceback.format_exc())