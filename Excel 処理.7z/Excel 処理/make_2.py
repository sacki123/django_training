import os
import jaconv
from xlrd import open_workbook
from openpyxl import Workbook

path= os.listdir(os.path.dirname(__file__) + "/input/")
path_file = os.path.dirname(__file__) + "/input/" + path[0]
wb = ""

def read_sheet_name(path_file):
    global wb
    wb = open_workbook(path_file)


def create_list():
    name_sheet = wb.sheet_names()
    shipping_list= []
    for j in name_sheet:   
        ws = wb.sheet_by_name(j)
        rows = ws.nrows
        for i in range(0,rows):
            temp = []
            # temp.append(ws.cell(i,0).value)
            temp.append(jaconv.z2h(clear_space(ws.cell(i,0).value),ascii=True,digit=True))
            # temp.append(jaconv.h2z(ws.cell(i,1).value,ascii=True,digit=True))
            # temp.append(clear_space(ws.cell(i,24).value))
            # temp.append(clear_space(ws.cell(i,25).value))
            # temp.append(clear_space(ws.cell(i,26).value))
            # shipping_address_town = clear_space(ws.cell(i,12).value)
            # shipping_address_town = filter_char(shipping_address_town)  
            # shipping_address_street = clear_space(ws.cell(i,13).value)
            # shipping_address_street = filter_char(shipping_address_street)
            # if shipping_address_street.startswith("一"):
            #     shipping_address_street = shipping_address_street.replace("一","１")
            # if shipping_address_street.startswith("二"):
            #     shipping_address_street = shipping_address_street.replace("二","２")    
            # if "丁目" in shipping_address_street:
            #     shipping_address_street = shipping_address_street.replace("丁目","－") 
            # if shipping_address_street[len(shipping_address_street) - 2:len(shipping_address_street)] == "番地":
            #     shipping_address_street = shipping_address_street.replace("番地","") 
            # if "番地の" in shipping_address_street:
            #     shipping_address_street = shipping_address_street.replace("番地の","－")         
            # if "番　地" in shipping_address_street:
            #     shipping_address_street = shipping_address_street.replace("番　地","－")   
            # # if "番地" in shipping_address_street:
            # #     shipping_address_street = shipping_address_street.replace("番地","－")  
            # if "‐" in shipping_address_street:
            #     shipping_address_street = shipping_address_street.replace("‐","－")
            # if shipping_address_street[-1] == "号":
            #     shipping_address_street = shipping_address_street.replace("号","")    
            # for char in ("ー","―","の","番地"):       
            #     shipping_address_street = find_string(shipping_address_street,char)
            # if "番" in shipping_address_street:
            #     shipping_address_street = shipping_address_street.replace("番","－")           
            # temp.extend([shipping_address_town,shipping_address_street])
            shipping_list.append(temp)
    return shipping_list

def clear_space(value):
    value = str(value).strip("　")
    value = value.strip(" ")
    return value

def filter_char(filter_str):
    for s in ("大字","小字","字"):
        if s in filter_str:
            filter_str = filter_str.replace(s,"")
    return  filter_str

def find_string(find_str,char):
    while True:
        d = find_str.find(char) 
        if char == "番地":
            if d != -1:
                t1 = (jaconv.z2h(find_str[d+2]))
                check = t1.isnumeric()
                if check:
                    find_str = find_str.replace(char,"－",1)
                else:
                    find_str = find_str.replace(char,"",1)
                    break
        if d != -1:
            t = (jaconv.z2h(find_str[d-1]))
            check = t.isnumeric()
            if check:
                find_str = find_str.replace(char,"－",1)
            else:
                break 
        else:
            break                   
    return find_str            

def create_excel(dic_main):
    wb = Workbook()
    ws = wb.active
    ws.title = "保険者送付先"
    excel_path = os.path.dirname(__file__) + '/FILLTER_EXCEL.xlsx' 
    for row in dic_main:
        ws.append(row)
    wb.save(excel_path)    
    
if (__name__ == "__main__" ):                
    read_sheet_name(path_file)
    main_list = create_list()
    create_excel(main_list)
print("OK")    
