import os
import jaconv
from xlrd import open_workbook
from openpyxl import Workbook

path= os.listdir(os.path.dirname(__file__) + "/input/")
path_file = os.path.dirname(__file__) + "/input/" + path[0]
wb = ""

def read_sheet_name(path_file):
    global wb
    wb = open_workbook(path_file)


def create_list():
    name_sheet = wb.sheet_names()
    shipping_list= []
    shipping_list.append(["RID","RECEIPT_ERROR","CHECK_1","CHECK_2"])
    Check_string = "同意書添付必要 （再同意"
    for j in name_sheet:   
        ws = wb.sheet_by_name(j)
        rows = ws.nrows
        for i in range(0,rows):
            temp = []
            touitsu_error_1 = ws.cell(i,1).value.split("\n")
            touitsu_error_2 = ws.cell(i,1).value
            find = touitsu_error_2.find(Check_string)
            if Check_string in touitsu_error_1:
                Check_1 = "TRUE"
            else:
                Check_1 = "FALSE"    
            if find != -1:
                Check_2 = "TRUE"
            else:   
                Check_2 = "FALSE"
            temp = [ws.cell(i,0).value,ws.cell(i,1).value,Check_1,Check_2]
            # temp.append(ws.cell(i,0).value)
            
            shipping_list.append(temp)
    return shipping_list

def clear_space(value):
    value = str(value).strip("　")
    value = value.strip(" ")
    return value

def filter_char(filter_str):
    for s in ("大字","小字","字"):
        if s in filter_str:
            filter_str = filter_str.replace(s,"")
    return  filter_str

def find_string(find_str,char):
    while True:
        d = find_str.find(char) 
        if char == "番地":
            if d != -1:
                t1 = (jaconv.z2h(find_str[d+2]))
                check = t1.isnumeric()
                if check:
                    find_str = find_str.replace(char,"－",1)
                else:
                    find_str = find_str.replace(char,"",1)
                    break
        if d != -1:
            t = (jaconv.z2h(find_str[d-1]))
            check = t.isnumeric()
            if check:
                find_str = find_str.replace(char,"－",1)
            else:
                break 
        else:
            break                   
    return find_str            

def create_excel(dic_main):
    wb = Workbook()
    ws = wb.active
    ws.title = "保険者送付先"
    excel_path = os.path.dirname(__file__) + '/FILLTER_EXCEL.xlsx' 
    for row in dic_main:
        ws.append(row)
    wb.save(excel_path)    
    
if (__name__ == "__main__" ):                
    read_sheet_name(path_file)
    main_list = create_list()
    create_excel(main_list)
print("OK")    
