import os
import copy
import csv
from openpyxl import Workbook
import mysql.connector as mydb
from mysql.connector import Error
path= os.listdir(os.path.dirname(__file__) + "/input/")
path_file = os.path.dirname(__file__) + "/input/" + path[0]
def connectdb():
    conn = mydb.connect(
        host='127.0.0.1',
        port='32767',
        user='zen',
        password='zen',
        database='zen'
    )
    return conn

def get_data(table):
    sql = f'select * from {table}'
    con = connectdb()
    cur = con.cursor()
    cur.execute(sql)
    data = cur.fetchall()
    con.close()
    cur.close()
    i = 0
    list_data = []
    for i in range(len(data)):
        list_data.append(list(data[i]))
    return list_data

def get_columns(table):
    list_columns = []
    sql = f'SHOW COLUMNS FROM {table}'
    con = connectdb()
    cur = con.cursor()
    cur.execute(sql)
    data = cur.fetchall()
    con.close()
    cur.close()
    for i in data:
        list_columns.append(i[0])
    return list_columns

def create_excel(table):
    columns = get_columns(table)
    data = get_data(table)
    data.insert(0,columns)
    excel_name = table + 'EXCELデータ'
    wb = Workbook()
    ws = wb.active
    ws.title = table
    excel_path = os.path.dirname(__file__) + '/' + excel_name + '.xlsx'
    for row_value in data:
        ws.append(row_value)
    wb.save(excel_path)        

def create_csv(table):
    columns = get_columns(table)
    data = get_data(table)
    data.insert(0,columns)
    csv_name = table + 'CSVデータ'
    csv_path = os.path.dirname(__file__) + '/' + csv_name + '.csv'
    with open(csv_path,'w',encoding='utf-8') as f:
        csv_writer = csv.writer(f)
        for row in data:
           csv_writer.writerow(row)  

inp = input("テープルの名前を入力してください：")
inp_table = "RECEIPT_" + str(inp)
create_excel(inp_table)
create_csv(inp_table)
print('SUCCESS')