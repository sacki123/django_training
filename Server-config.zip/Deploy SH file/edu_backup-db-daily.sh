#!/bin/bash

BACKUP_FOLDER="/export/db-mariadb/dump"
sudo mkdir -p $BACKUP_FOLDER
DATE=`date "+%Y%m%d"`

# file name
WEB_FILE_NAME="zen-bk-web-$DATE.sql"
WEB_INSERT_FILE_NAME="zen-bk-web-insert-$DATE.sql"
BATCH_FILE_NAME="zen-bk-batch-$DATE.sql"

# set password
if [ -z "$WEB_DB_PASSWORD" ]; then
  export WEB_DB_PASSWORD=zentester2019
fi
if [ -z "$BATCH_DB_PASSWORD" ]; then
  export BATCH_DB_PASSWORD=zentester2019
fi

BACKUP_PATH="$BACKUP_FOLDER/$DATE"
mkdir -p $BACKUP_PATH

mysqldump -u zen -p$WEB_DB_PASSWORD zen > $BACKUP_PATH/$WEB_FILE_NAME
mysqldump -u zen -p$WEB_DB_PASSWORD --complete-insert zen > $BACKUP_PATH/$WEB_INSERT_FILE_NAME
mysqldump -u zen -p$BATCH_DB_PASSWORD zen_report > $BACKUP_PATH/$BATCH_FILE_NAME

#zip file backup
gzip $BACKUP_PATH/$WEB_FILE_NAME
gzip $BACKUP_PATH/$WEB_INSERT_FILE_NAME
gzip $BACKUP_PATH/$BATCH_FILE_NAME

# delete old backup file
OLD_DATE=$(date --date="7 day ago" +"%Y%m%d")
OLD_PATH="$BACKUP_FOLDER/$OLD_DATE"

if [ -d "$OLD_PATH" ]; then
  rm -rf $OLD_PATH
fi