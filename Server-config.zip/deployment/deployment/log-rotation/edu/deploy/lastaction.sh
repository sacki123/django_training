#!/bin/bash

DOCKER_COMPOSE_FILE=/export/docker-compose-deploy.yml
SERVICES=(deploy-private-registry)

for SERVICE in $SERVICES; do
        SERVICE_ID=$(sudo docker-compose -f $DOCKER_COMPOSE_FILE ps -q $SERVICE)
        echo $SERVICE_ID
        LOG_DIR="/var/lib/docker/containers/$SERVICE_ID/"
        LOGBK_DIR="/export/logs/$SERVICE/"
        bash /etc/cp-log.sh  $LOG_DIR $LOGBK_DIR \*.log.\*
        bash /etc/remove-old-log.sh  $LOG_DIR $LOGBK_DIR 180
done