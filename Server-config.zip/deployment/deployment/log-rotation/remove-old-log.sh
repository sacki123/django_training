#!/bin/sh

##########################
## Variable
##########################
LOG_DIR=$1
LOGBK_DIR=$2
RM_DAYS=180
TODAY=$(date "+%Y%m%d")


##########################
## main
##########################
for file in `\find $LOGBK_DIR -maxdepth 1 -type f`; do
    if [[ -f $file ]]; then
        FILE_CREATED_DATE=${file: -8}

        #### 改行を除いた文字の Bytes 数取得
        #### wc -c の結果には、改行も含まれるので改行は、取り除く
        DATE_CHARS=`echo $FILE_CREATED_DATE | tr -d '\n' | wc -c`

        #### 数字 8文字パターンチェック
        #### 正常 : 0
        #### 異常 : 0 以外
        MATCH='[0-9]{8}'
        echo "$FILE_CREATED_DATE" | grep -wE "$MATCH"  > /dev/null 2>&1
        RES_1=$?

        #### 日付フォーマットチェック
        #### 正常 : 0
        #### 異常 : 0 以外
        date +%Y%m%d --date "$FILE_CREATED_DATE" > /dev/null 2>&1
        RES_2=$?

        if [ $DATE_CHARS -eq 8 -a $RES_1 -eq 0 -a $RES_2 -eq 0 ]; then
            # Dateformat
            :
        else
            # Not Dateformat
            continue
        fi

        OLD_DATE=`date --date "$TODAY $RM_DAYS days ago" "+%Y%m%d"`
        dt1=`date -d "$FILE_CREATED_DATE" '+%s'`
        dt2=`date -d "$OLD_DATE" '+%s'`

        if [ $dt1 -lt $dt2 ]; then
            # Remove
            rm -f $file
        fi
    fi
done
