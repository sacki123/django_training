#!/bin/sh

##########################
## Variable
##########################
LOG_DIR=$1
LOGBK_DIR=$2
FILE_NAME=$3
TODAY=$(date "+%Y%m%d")

##########################
## Logrotation
##########################
for file in `find $LOG_DIR -maxdepth 1 -name $FILE_NAME `; do
    if [[ -f $file ]]; then
        newfile=(${file/.$TODAY/})
        cp $file $LOGBK_DIR
        mv $file $newfile
        cat /dev/null > $newfile
    fi
done
