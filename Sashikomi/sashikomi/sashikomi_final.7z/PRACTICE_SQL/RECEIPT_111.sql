select * 
from RECEIPT_111
