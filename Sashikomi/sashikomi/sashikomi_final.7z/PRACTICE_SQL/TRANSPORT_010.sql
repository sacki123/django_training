select * 
from TRANSPORT_010
