select * 
from RECEIPT_205
