select * 
from MONEY_310
