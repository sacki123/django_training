select * 
from CHECK_011
