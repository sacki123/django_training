select * 
from CHECK_002
