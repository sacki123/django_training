select * 
from MEMBER_001
