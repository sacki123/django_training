select * 
from RECEIPT_100
