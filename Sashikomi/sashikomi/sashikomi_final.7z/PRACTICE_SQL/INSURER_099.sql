select * 
from INSURER_099
