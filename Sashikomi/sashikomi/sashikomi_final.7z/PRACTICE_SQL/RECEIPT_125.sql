select * 
from RECEIPT_125
