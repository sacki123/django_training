select * 
from AUTHORIZE_000
