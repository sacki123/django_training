select * 
from RECEIPT_200
