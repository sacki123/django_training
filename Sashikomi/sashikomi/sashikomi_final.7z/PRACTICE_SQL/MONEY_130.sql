select * 
from MONEY_130
