select * 
from RECEIPT_110
