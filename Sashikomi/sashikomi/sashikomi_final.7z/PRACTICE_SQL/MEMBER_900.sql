select * 
from MEMBER_900
