select * 
from REMITTANCE_001
