select * 
from FACILITY_010
