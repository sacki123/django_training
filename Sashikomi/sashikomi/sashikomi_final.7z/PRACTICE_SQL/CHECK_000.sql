select * 
from CHECK_000
