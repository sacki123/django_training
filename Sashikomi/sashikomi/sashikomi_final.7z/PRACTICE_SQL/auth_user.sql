select * 
from auth_user
