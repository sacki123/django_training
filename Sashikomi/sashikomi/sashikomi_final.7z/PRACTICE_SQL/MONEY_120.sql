select * 
from MONEY_120
