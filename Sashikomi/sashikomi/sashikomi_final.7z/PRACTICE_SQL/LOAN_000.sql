select * 
from LOAN_000
