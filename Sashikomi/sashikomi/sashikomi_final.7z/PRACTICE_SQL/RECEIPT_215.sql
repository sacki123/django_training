select * 
from RECEIPT_215
