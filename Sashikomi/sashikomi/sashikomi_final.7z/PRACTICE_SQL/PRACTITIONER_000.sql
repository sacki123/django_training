select * 
from PRACTITIONER_000
