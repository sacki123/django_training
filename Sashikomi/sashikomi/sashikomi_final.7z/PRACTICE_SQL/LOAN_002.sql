select * 
from LOAN_002
