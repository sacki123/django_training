select * 
from RECEIPT_115
