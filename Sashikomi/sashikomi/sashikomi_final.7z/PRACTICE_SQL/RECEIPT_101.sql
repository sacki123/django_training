select * 
from RECEIPT_101
