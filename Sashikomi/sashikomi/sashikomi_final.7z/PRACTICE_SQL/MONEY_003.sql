select * 
from MONEY_003
