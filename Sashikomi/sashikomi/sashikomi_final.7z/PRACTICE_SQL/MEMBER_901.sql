select * 
from MEMBER_901
