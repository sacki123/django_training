select * 
from MONEY_099
