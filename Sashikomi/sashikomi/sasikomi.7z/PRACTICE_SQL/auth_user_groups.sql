select * 
from auth_user_groups
