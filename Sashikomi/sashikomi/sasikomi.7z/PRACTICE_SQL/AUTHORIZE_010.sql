select * 
from AUTHORIZE_010
