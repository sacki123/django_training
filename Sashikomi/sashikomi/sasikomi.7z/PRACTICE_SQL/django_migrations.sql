select * 
from django_migrations
