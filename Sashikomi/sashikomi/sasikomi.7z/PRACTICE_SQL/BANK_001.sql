select * 
from BANK_001
