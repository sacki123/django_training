select * 
from REMITTANCE_003
