select * 
from RECEIPT_305
