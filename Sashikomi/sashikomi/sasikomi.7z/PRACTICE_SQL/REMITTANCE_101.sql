select * 
from REMITTANCE_101
