select * 
from auth_group_permissions
