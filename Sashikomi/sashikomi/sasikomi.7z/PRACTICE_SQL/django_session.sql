select * 
from django_session
