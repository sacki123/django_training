select * 
from FACILITY_003
