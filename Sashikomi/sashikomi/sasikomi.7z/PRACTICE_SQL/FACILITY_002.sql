select * 
from FACILITY_002
