select * 
from INSURER_001
