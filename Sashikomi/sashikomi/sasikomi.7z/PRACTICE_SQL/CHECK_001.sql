select * 
from CHECK_001
