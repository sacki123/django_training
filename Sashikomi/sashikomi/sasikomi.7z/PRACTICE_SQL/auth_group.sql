select * 
from auth_group
