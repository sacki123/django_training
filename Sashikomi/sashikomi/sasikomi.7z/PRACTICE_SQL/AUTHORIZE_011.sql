select * 
from AUTHORIZE_011
