select * 
from PRACTITIONER_001
