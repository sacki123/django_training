select * 
from MONEY_001
