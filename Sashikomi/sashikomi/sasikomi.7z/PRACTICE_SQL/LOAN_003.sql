select * 
from LOAN_003
