select * 
from django_admin_log
