select * 
from REMITTANCE_100
