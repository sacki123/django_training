select * 
from REMITTANCE_004
