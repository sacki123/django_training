select * 
from RECEIPT_220
