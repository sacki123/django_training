select * 
from MONEY_050
