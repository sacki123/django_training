select * 
from RECEIPT_300
