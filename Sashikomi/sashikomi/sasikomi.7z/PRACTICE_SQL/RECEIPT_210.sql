select * 
from RECEIPT_210
