select * 
from INSURER_010
