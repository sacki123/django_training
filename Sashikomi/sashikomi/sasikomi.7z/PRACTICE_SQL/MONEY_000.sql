select * 
from MONEY_000
