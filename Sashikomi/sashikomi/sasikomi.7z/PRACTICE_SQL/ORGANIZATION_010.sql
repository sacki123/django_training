select * 
from ORGANIZATION_010
