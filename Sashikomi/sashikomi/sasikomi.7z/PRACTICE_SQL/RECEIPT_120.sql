select * 
from RECEIPT_120
