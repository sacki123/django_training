select * 
from MONEY_125
