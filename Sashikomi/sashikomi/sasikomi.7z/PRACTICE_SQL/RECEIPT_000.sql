select * 
from RECEIPT_000
