select * 
from PRACTITIONER_002
