select * 
from RECEIPT_225
