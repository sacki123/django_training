select * 
from AUTHORIZE_001
