select * 
from TRANSPORT_002
