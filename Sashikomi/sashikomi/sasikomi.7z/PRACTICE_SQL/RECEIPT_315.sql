select * 
from RECEIPT_315
