select * 
from auth_permission
