select * 
from MEMBER_002
