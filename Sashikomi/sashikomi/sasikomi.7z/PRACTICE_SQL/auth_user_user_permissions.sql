select * 
from auth_user_user_permissions
