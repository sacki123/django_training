select * 
from CHECK_013
