select * 
from RECEIPT_310
