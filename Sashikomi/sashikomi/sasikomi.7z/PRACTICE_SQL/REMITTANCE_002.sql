select * 
from REMITTANCE_002
