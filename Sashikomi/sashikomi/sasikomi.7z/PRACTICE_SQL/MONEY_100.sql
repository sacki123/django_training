select * 
from MONEY_100
