select * 
from MONEY_002
