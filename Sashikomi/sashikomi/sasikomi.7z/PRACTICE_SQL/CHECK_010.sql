select * 
from CHECK_010
