select * 
from MONEY_110
