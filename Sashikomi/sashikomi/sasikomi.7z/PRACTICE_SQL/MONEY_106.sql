select * 
from MONEY_106
