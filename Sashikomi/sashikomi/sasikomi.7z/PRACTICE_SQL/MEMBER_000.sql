select * 
from MEMBER_000
