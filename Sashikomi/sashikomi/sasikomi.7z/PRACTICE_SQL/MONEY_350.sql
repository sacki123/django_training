select * 
from MONEY_350
