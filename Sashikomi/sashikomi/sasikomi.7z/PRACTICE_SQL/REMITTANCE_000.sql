select * 
from REMITTANCE_000
