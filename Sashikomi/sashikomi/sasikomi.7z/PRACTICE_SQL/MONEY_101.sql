select * 
from MONEY_101
