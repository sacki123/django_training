select * 
from django_content_type
