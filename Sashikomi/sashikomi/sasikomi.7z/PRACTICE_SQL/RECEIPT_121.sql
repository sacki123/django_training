select * 
from RECEIPT_121
