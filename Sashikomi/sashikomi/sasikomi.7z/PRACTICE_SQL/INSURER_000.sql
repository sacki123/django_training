select * 
from INSURER_000
