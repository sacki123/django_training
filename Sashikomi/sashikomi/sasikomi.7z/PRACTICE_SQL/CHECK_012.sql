select * 
from CHECK_012
