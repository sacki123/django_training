select * 
from LOAN_001
