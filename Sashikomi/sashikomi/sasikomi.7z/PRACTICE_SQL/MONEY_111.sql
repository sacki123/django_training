select * 
from MONEY_111
