select * 
from REMITTANCE_102
