select * 
from RECEIPT_105
