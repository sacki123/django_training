select * 
from CHECK_014
